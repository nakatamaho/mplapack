/*
 * Copyright (c) 2026
 *      Nakata, Maho
 *      All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 */

#ifndef GMPFRXX_MKII_DETAIL_CONFIG_HPP
#define GMPFRXX_MKII_DETAIL_CONFIG_HPP

#include <cassert>
#include <ostream>

#define GMPXX_MKII_DEFAULT_CONTEXT_FROZEN_ENV 0
#define GMPXX_MKII_DEFAULT_CONTEXT_EXTERNAL_PROVIDER 1

#ifndef GMPXX_MKII_DEFAULT_CONTEXT_MODE
#define GMPXX_MKII_DEFAULT_CONTEXT_MODE GMPXX_MKII_DEFAULT_CONTEXT_FROZEN_ENV
#endif

#if GMPXX_MKII_DEFAULT_CONTEXT_MODE != GMPXX_MKII_DEFAULT_CONTEXT_FROZEN_ENV && \
    GMPXX_MKII_DEFAULT_CONTEXT_MODE != GMPXX_MKII_DEFAULT_CONTEXT_EXTERNAL_PROVIDER
#error "GMPXX_MKII_DEFAULT_CONTEXT_MODE must be GMPXX_MKII_DEFAULT_CONTEXT_FROZEN_ENV or GMPXX_MKII_DEFAULT_CONTEXT_EXTERNAL_PROVIDER"
#endif

#ifndef GMPXX_MKII_API
#define GMPXX_MKII_API
#endif

#ifndef GMPFRXX_MKII_HIDDEN
#if defined(__GNUC__) || defined(__clang__)
#define GMPFRXX_MKII_HIDDEN __attribute__((visibility("hidden")))
#else
#define GMPFRXX_MKII_HIDDEN
#endif
#endif

#ifndef GMPFRXX_MKII_ALWAYS_INLINE
#if defined(_MSC_VER)
#define GMPFRXX_MKII_ALWAYS_INLINE __forceinline
#elif defined(__GNUC__) || defined(__clang__)
#define GMPFRXX_MKII_ALWAYS_INLINE inline __attribute__((always_inline))
#else
#define GMPFRXX_MKII_ALWAYS_INLINE inline
#endif
#endif

#ifndef GMPFRXX_MKII_ASSERT_FAST_FIXED_PREC_CONTRACT
#define GMPFRXX_MKII_ASSERT_FAST_FIXED_PREC_CONTRACT(condition, message) \
    assert((condition) && "GMPFRXX_MKII_FAST_FIXED_PREC contract violation: " message)
#endif

#if __has_include(<gmpfrxx_mkII/detail/version.hpp>)
#include <gmpfrxx_mkII/detail/version.hpp>
#else
#define GMPFRXX_MKII_VERSION "1.4.3"
#define GMPFRXX_MKII_GIT_COMMIT_HASH "unknown"

namespace gmpfrxx_mkII {
namespace detail {

inline constexpr const char* version = GMPFRXX_MKII_VERSION;
inline constexpr const char* git_commit_hash = GMPFRXX_MKII_GIT_COMMIT_HASH;

} // namespace detail
} // namespace gmpfrxx_mkII
#endif

#if __has_include(<gmpfrxx_mkII/detail/build_config.hpp>)
#include <gmpfrxx_mkII/detail/build_config.hpp>
#else
#define GMPFRXX_MKII_MPFR_HAS_BUILDOPT_TLS_P 0
#define GMPFRXX_MKII_MPFR_BUILDOPT_TLS 0
#define GMPFRXX_MKII_MPC_HAS_BUILDOPT_TLS_P 0
#define GMPFRXX_MKII_MPC_BUILDOPT_TLS 0
#endif

namespace gmpfrxx_mkII {
namespace detail {

struct build_options {
#ifdef GMPFRXX_MKII_FAST_FIXED_PREC
    static constexpr bool fast_fixed_precision = true;
#else
    static constexpr bool fast_fixed_precision = false;
#endif
#ifdef GMPFRXX_MKII_ENABLE_FMA
    static constexpr bool enable_fma = true;
#else
    static constexpr bool enable_fma = false;
#endif
#ifdef GMPFRXX_MKII_FAST_STABLE_RND
    static constexpr bool fast_stable_rounding = true;
#else
    static constexpr bool fast_stable_rounding = false;
#endif
    static constexpr bool mpfr_has_buildopt_tls_p = GMPFRXX_MKII_MPFR_HAS_BUILDOPT_TLS_P != 0;
    static constexpr bool mpfr_buildopt_tls = GMPFRXX_MKII_MPFR_BUILDOPT_TLS != 0;
    static constexpr bool mpc_has_buildopt_tls_p = GMPFRXX_MKII_MPC_HAS_BUILDOPT_TLS_P != 0;
    static constexpr bool mpc_buildopt_tls = GMPFRXX_MKII_MPC_BUILDOPT_TLS != 0;
    static constexpr int gmp_default_context_mode = GMPXX_MKII_DEFAULT_CONTEXT_MODE;
};

} // namespace detail
} // namespace gmpfrxx_mkII

namespace gmpxx {

inline constexpr const char* version() noexcept
{
    return ::gmpfrxx_mkII::detail::version;
}

inline std::ostream& print_version(std::ostream& out)
{
    return out << version();
}

inline constexpr const char* git_commit_hash() noexcept
{
    return ::gmpfrxx_mkII::detail::git_commit_hash;
}

inline std::ostream& print_git_commit_hash(std::ostream& out)
{
    return out << git_commit_hash();
}

} // namespace gmpxx

namespace mpfrxx {

inline constexpr const char* version() noexcept
{
    return ::gmpfrxx_mkII::detail::version;
}

inline std::ostream& print_version(std::ostream& out)
{
    return out << version();
}

inline constexpr const char* git_commit_hash() noexcept
{
    return ::gmpfrxx_mkII::detail::git_commit_hash;
}

inline std::ostream& print_git_commit_hash(std::ostream& out)
{
    return out << git_commit_hash();
}

} // namespace mpfrxx

#endif // GMPFRXX_MKII_DETAIL_CONFIG_HPP
