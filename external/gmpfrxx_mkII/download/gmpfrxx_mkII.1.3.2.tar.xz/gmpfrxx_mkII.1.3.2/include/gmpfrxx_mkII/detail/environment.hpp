/*
 * Copyright (c) 2026
 *      Nakata, Maho
 *      All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 */

#ifndef GMPFRXX_MKII_DETAIL_ENVIRONMENT_HPP
#define GMPFRXX_MKII_DETAIL_ENVIRONMENT_HPP

#include <gmpfrxx_mkII/detail/config.hpp>

#include <algorithm>
#include <cerrno>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <limits>
#include <stdexcept>

#include <mpfr.h>

namespace gmpfrxx_mkII {
namespace detail {

struct parsed_mpfr_environment {
    mpfr_prec_t precision;
    mpfr_exp_t emin;
    mpfr_exp_t emax;
    mpfr_rnd_t rounding;
};

inline mpfr_prec_t builtin_mpfr_default_precision() noexcept
{
    return 512;
}

inline mpfr_prec_t mpfr_library_default_precision() noexcept
{
    return 53;
}

inline mpfr_rnd_t builtin_mpfr_default_rounding() noexcept
{
    return mpfr_get_default_rounding_mode();
}

inline mpfr_rnd_t& stable_mpfr_rounding_mode_storage() noexcept
{
    static thread_local mpfr_rnd_t rounding = MPFR_RNDN;
    return rounding;
}

inline mpfr_rnd_t stable_mpfr_rounding_mode() noexcept
{
    return stable_mpfr_rounding_mode_storage();
}

inline void refresh_stable_mpfr_rounding_mode() noexcept
{
    stable_mpfr_rounding_mode_storage() = mpfr_get_default_rounding_mode();
}

inline bool valid_mpfr_precision(mpfr_prec_t precision) noexcept
{
    return precision >= MPFR_PREC_MIN && precision <= MPFR_PREC_MAX;
}

inline void require_valid_mpfr_precision(mpfr_prec_t precision)
{
    if (!valid_mpfr_precision(precision)) {
        throw std::invalid_argument("invalid MPFR precision");
    }
}

inline bool parse_mpfr_precision(const char* text, mpfr_prec_t& out) noexcept
{
    // Require a leading decimal digit so strtoull cannot silently accept
    // leading whitespace or '+', matching the strict GMP MPF parser.
    if (text == nullptr || *text < '0' || *text > '9') {
        return false;
    }
    errno = 0;
    char* end = nullptr;
    const unsigned long long value = std::strtoull(text, &end, 10);
    if (errno != 0 || end == text || *end != '\0' || value == 0) {
        return false;
    }
    if (value > static_cast<unsigned long long>(std::numeric_limits<mpfr_prec_t>::max())) {
        return false;
    }
    if (value < static_cast<unsigned long long>(MPFR_PREC_MIN) ||
        value > static_cast<unsigned long long>(MPFR_PREC_MAX)) {
        return false;
    }
    out = static_cast<mpfr_prec_t>(value);
    return true;
}

inline bool parse_mpfr_exponent(const char* text, mpfr_exp_t& out) noexcept
{
    if (text == nullptr || *text == '\0') {
        return false;
    }
    errno = 0;
    char* end = nullptr;
    const long long value = std::strtoll(text, &end, 10);
    if (errno != 0 || end == text || *end != '\0') {
        return false;
    }
    if (value < static_cast<long long>(std::numeric_limits<mpfr_exp_t>::min()) ||
        value > static_cast<long long>(std::numeric_limits<mpfr_exp_t>::max())) {
        return false;
    }
    out = static_cast<mpfr_exp_t>(value);
    return true;
}

inline bool valid_mpfr_exponent_range(mpfr_exp_t emin, mpfr_exp_t emax) noexcept
{
    return emin <= emax &&
           emin >= mpfr_get_emin_min() &&
           emin <= mpfr_get_emin_max() &&
           emax >= mpfr_get_emax_min() &&
           emax <= mpfr_get_emax_max();
}

inline bool parse_mpfr_rounding(const char* text, mpfr_rnd_t& out) noexcept
{
    if (text == nullptr) {
        return false;
    }

    if (std::strcmp(text, "RNDN") == 0 || std::strcmp(text, "MPFR_RNDN") == 0) {
        out = MPFR_RNDN;
        return true;
    }
    if (std::strcmp(text, "RNDZ") == 0 || std::strcmp(text, "MPFR_RNDZ") == 0) {
        out = MPFR_RNDZ;
        return true;
    }
    if (std::strcmp(text, "RNDU") == 0 || std::strcmp(text, "MPFR_RNDU") == 0) {
        out = MPFR_RNDU;
        return true;
    }
    if (std::strcmp(text, "RNDD") == 0 || std::strcmp(text, "MPFR_RNDD") == 0) {
        out = MPFR_RNDD;
        return true;
    }
    if (std::strcmp(text, "RNDA") == 0 || std::strcmp(text, "MPFR_RNDA") == 0) {
        out = MPFR_RNDA;
        return true;
    }
    if (std::strcmp(text, "RNDF") == 0 || std::strcmp(text, "MPFR_RNDF") == 0) {
        out = MPFR_RNDF;
        return true;
    }

    return false;
}

inline void warn_invalid_environment_value(const char* variable, const char* value) noexcept
{
    if (value != nullptr) {
        std::fprintf(stderr,
                     "gmpfrxx_mkII: ignoring invalid environment value %s=%s\n",
                     variable,
                     value);
    }
}

inline void warn_invalid_mpfr_exponent_range(const char* emin_text, const char* emax_text) noexcept
{
    std::fprintf(stderr,
                 "gmpfrxx_mkII: ignoring invalid MPFR exponent range MPFRXX_DEFAULT_EMIN=%s MPFRXX_DEFAULT_EMAX=%s\n",
                 emin_text != nullptr ? emin_text : "<unset>",
                 emax_text != nullptr ? emax_text : "<unset>");
}

inline parsed_mpfr_environment load_mpfr_environment() noexcept
{
    parsed_mpfr_environment result{
        builtin_mpfr_default_precision(),
        mpfr_get_emin(),
        mpfr_get_emax(),
        builtin_mpfr_default_rounding(),
    };

    const char* precision_text = std::getenv("MPFRXX_DEFAULT_PRECISION_BITS");
    mpfr_prec_t precision = result.precision;
    if (parse_mpfr_precision(precision_text, precision)) {
        result.precision = precision;
    } else {
        warn_invalid_environment_value("MPFRXX_DEFAULT_PRECISION_BITS", precision_text);
    }

    mpfr_exp_t emin = result.emin;
    mpfr_exp_t emax = result.emax;
    const char* emin_text = std::getenv("MPFRXX_DEFAULT_EMIN");
    const char* emax_text = std::getenv("MPFRXX_DEFAULT_EMAX");
    const bool has_emin = parse_mpfr_exponent(emin_text, emin);
    const bool has_emax = parse_mpfr_exponent(emax_text, emax);
    if (!has_emin) {
        warn_invalid_environment_value("MPFRXX_DEFAULT_EMIN", emin_text);
    }
    if (!has_emax) {
        warn_invalid_environment_value("MPFRXX_DEFAULT_EMAX", emax_text);
    }
    bool applied_exponent_range = false;
    if (has_emin && has_emax && valid_mpfr_exponent_range(emin, emax)) {
        result.emin = emin;
        result.emax = emax;
        applied_exponent_range = true;
    } else if (has_emin && !has_emax && valid_mpfr_exponent_range(emin, result.emax)) {
        result.emin = emin;
        applied_exponent_range = true;
    } else if (!has_emin && has_emax && valid_mpfr_exponent_range(result.emin, emax)) {
        result.emax = emax;
        applied_exponent_range = true;
    }
    if ((has_emin || has_emax) && !applied_exponent_range) {
        warn_invalid_mpfr_exponent_range(emin_text, emax_text);
    }

    mpfr_rnd_t rounding = result.rounding;
    const char* rounding_text = std::getenv("MPFRXX_DEFAULT_ROUNDING_MODE");
    if (parse_mpfr_rounding(rounding_text, rounding)) {
        result.rounding = rounding;
    } else {
        warn_invalid_environment_value("MPFRXX_DEFAULT_ROUNDING_MODE", rounding_text);
    }

    return result;
}

inline bool set_mpfr_default_exponent_range(mpfr_exp_t emin, mpfr_exp_t emax) noexcept
{
    if (!valid_mpfr_exponent_range(emin, emax)) {
        return false;
    }

    const mpfr_exp_t current_emin = mpfr_get_emin();
    const mpfr_exp_t current_emax = mpfr_get_emax();

    const auto apply_ordered = [](mpfr_exp_t target_emin, mpfr_exp_t target_emax) noexcept {
        const mpfr_exp_t from_emax = mpfr_get_emax();

        if (target_emax > from_emax && mpfr_set_emax(target_emax) != 0) {
            return false;
        }
        if (mpfr_set_emin(target_emin) != 0) {
            return false;
        }
        if (target_emax <= from_emax && mpfr_set_emax(target_emax) != 0) {
            return false;
        }
        return mpfr_get_emin() == target_emin && mpfr_get_emax() == target_emax;
    };

    if (apply_ordered(emin, emax)) {
        return true;
    }

    if (!apply_ordered(current_emin, current_emax)) {
        std::fprintf(
            stderr,
            "gmpfrxx_mkII: failed to restore MPFR exponent range after set failure; aborting\n");
        std::abort();
    }
    return false;
}

inline void apply_mpfr_environment_defaults() noexcept
{
    const auto loaded = load_mpfr_environment();
    if (valid_mpfr_precision(loaded.precision)) {
        mpfr_set_default_prec(loaded.precision);
    }
    set_mpfr_default_exponent_range(loaded.emin, loaded.emax);
    mpfr_set_default_rounding_mode(loaded.rounding);
    refresh_stable_mpfr_rounding_mode();
}

inline bool& mpfr_defaults_initialized_storage() noexcept
{
    static thread_local bool initialized = false;
    return initialized;
}

inline bool mpfr_default_state_is_library_initial() noexcept
{
    return mpfr_get_default_prec() == mpfr_library_default_precision() &&
           mpfr_get_default_rounding_mode() == MPFR_RNDN &&
           mpfr_get_emin() == MPFR_EMIN_DEFAULT &&
           mpfr_get_emax() == MPFR_EMAX_DEFAULT;
}

inline bool mpfr_runtime_tls_supported() noexcept
{
    static const bool supported = [] {
        const bool ok = mpfr_buildopt_tls_p() != 0;
        if (!ok) {
            std::fprintf(stderr,
                         "gmpfrxx_mkII: libmpfr was built without TLS support; "
                         "per-thread MPFR default state is unavailable\n");
        }
        return ok;
    }();
    return supported;
}

inline void initialize_mpfr_defaults_for_current_thread() noexcept
{
    auto& initialized = mpfr_defaults_initialized_storage();
    if (initialized) {
        return;
    }
    initialized = true;

    (void)mpfr_runtime_tls_supported();

    // The flag is intentionally DSO-local TLS, matching the wrapper's stable
    // rounding cache. It keeps hot evaluation-context reads from repeatedly
    // probing MPFR's TLS defaults while preserving first-use initialization.
    if (mpfr_default_state_is_library_initial()) {
        apply_mpfr_environment_defaults();
    }
    refresh_stable_mpfr_rounding_mode();
}

inline mpfr_rnd_t current_mpfr_rounding_mode() noexcept
{
    initialize_mpfr_defaults_for_current_thread();
    if constexpr (build_options::fast_stable_rounding) {
        return stable_mpfr_rounding_mode();
    } else {
        return mpfr_get_default_rounding_mode();
    }
}

} // namespace detail
} // namespace gmpfrxx_mkII

namespace mpfrxx {

struct mpfr_default_options {
    mpfr_prec_t precision_bits;
    mpfr_exp_t emin;
    mpfr_exp_t emax;
    mpfr_rnd_t rounding_mode;
};

inline void reload_mpfr_defaults_from_environment() noexcept
{
    ::gmpfrxx_mkII::detail::initialize_mpfr_defaults_for_current_thread();
    ::gmpfrxx_mkII::detail::apply_mpfr_environment_defaults();
}

inline void initialize_thread_defaults() noexcept
{
    ::gmpfrxx_mkII::detail::initialize_mpfr_defaults_for_current_thread();
}

inline mpfr_default_options default_options() noexcept
{
    ::gmpfrxx_mkII::detail::initialize_mpfr_defaults_for_current_thread();
    return mpfr_default_options{
        mpfr_get_default_prec(),
        mpfr_get_emin(),
        mpfr_get_emax(),
        mpfr_get_default_rounding_mode(),
    };
}

inline mpfr_prec_t default_precision_bits() noexcept
{
    ::gmpfrxx_mkII::detail::initialize_mpfr_defaults_for_current_thread();
    return mpfr_get_default_prec();
}

inline mpfr_prec_t default_prec() noexcept
{
    return default_precision_bits();
}

inline void set_default_precision_bits(mpfr_prec_t precision) noexcept
{
    ::gmpfrxx_mkII::detail::initialize_mpfr_defaults_for_current_thread();
    if (::gmpfrxx_mkII::detail::valid_mpfr_precision(precision)) {
        mpfr_set_default_prec(precision);
    }
}

inline mpfr_rnd_t default_rounding_mode() noexcept
{
    return ::gmpfrxx_mkII::detail::current_mpfr_rounding_mode();
}

inline void set_default_rounding_mode(mpfr_rnd_t rounding) noexcept
{
    ::gmpfrxx_mkII::detail::initialize_mpfr_defaults_for_current_thread();
    mpfr_set_default_rounding_mode(rounding);
    ::gmpfrxx_mkII::detail::refresh_stable_mpfr_rounding_mode();
}

class rounding_mode_scope {
public:
    explicit rounding_mode_scope(mpfr_rnd_t rounding) noexcept
        : saved_(capture_current_rounding_state())
    {
        mpfr_set_default_rounding_mode(rounding);
        ::gmpfrxx_mkII::detail::refresh_stable_mpfr_rounding_mode();
    }

    ~rounding_mode_scope() noexcept
    {
        mpfr_set_default_rounding_mode(saved_.default_rounding);
        ::gmpfrxx_mkII::detail::stable_mpfr_rounding_mode_storage() = saved_.stable_rounding;
    }

    rounding_mode_scope(const rounding_mode_scope&) = delete;
    rounding_mode_scope& operator=(const rounding_mode_scope&) = delete;

private:
    struct saved_rounding_state {
        mpfr_rnd_t default_rounding;
        mpfr_rnd_t stable_rounding;
    };

    static saved_rounding_state capture_current_rounding_state() noexcept
    {
        ::gmpfrxx_mkII::detail::initialize_mpfr_defaults_for_current_thread();
        return saved_rounding_state{
            mpfr_get_default_rounding_mode(),
            ::gmpfrxx_mkII::detail::stable_mpfr_rounding_mode(),
        };
    }

    saved_rounding_state saved_;
};

inline mpfr_exp_t default_emin() noexcept
{
    ::gmpfrxx_mkII::detail::initialize_mpfr_defaults_for_current_thread();
    return mpfr_get_emin();
}

inline mpfr_exp_t default_emax() noexcept
{
    ::gmpfrxx_mkII::detail::initialize_mpfr_defaults_for_current_thread();
    return mpfr_get_emax();
}

inline void set_default_exponent_range(mpfr_exp_t emin, mpfr_exp_t emax) noexcept
{
    ::gmpfrxx_mkII::detail::initialize_mpfr_defaults_for_current_thread();
    ::gmpfrxx_mkII::detail::set_mpfr_default_exponent_range(emin, emax);
}

} // namespace mpfrxx

#endif // GMPFRXX_MKII_DETAIL_ENVIRONMENT_HPP
