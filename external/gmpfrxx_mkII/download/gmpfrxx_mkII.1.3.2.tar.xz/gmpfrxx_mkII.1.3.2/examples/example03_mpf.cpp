/*
 * Copyright (c) 2026
 *      Nakata, Maho
 *      All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 */

/*
 * Example 03: Newton iteration for sqrt(2).
 *
 * The iteration
 *
 *     x_{k+1} = (x_k + 2 / x_k) / 2
 *
 * is the classical Newton/Heron iteration applied to f(x) = x^2 - 2.
 * In this example it is useful because it exercises repeated expression
 * evaluation, division, assignment into an existing mpf_class, and a
 * precision-dependent stopping test.  The final value is compared with the
 * library sqrt() overload, which must remain GMP-backed rather than falling
 * through to a double overload.
 *
 * This method predates the DOI system by centuries, so there is no honest
 * DOI-bearing first-publication reference for the historical algorithm.
 */

#include <gmpxx_mkII.h>

#include <cmath>
#include <iomanip>
#include <iostream>

using namespace gmpxx;

int main()
{
    constexpr int decimal_digits = 50;

    mpf_class x("1.0");
    mpf_class previous("0.0");
    mpf_class two("2.0");
    mpf_class tolerance =
        exp2(-mpf_class(default_mpf_precision_bits() / 2));

    std::cout << std::fixed << std::setprecision(decimal_digits);
    std::cout << "Newton iteration for sqrt(2)\n";

    int iteration = 0;
    do {
        previous = x;
        x = (x + two / x) / two;
        ++iteration;
        std::cout << "iteration " << std::setw(2) << iteration
                  << ": " << x << '\n';
    } while (abs(x - previous) > tolerance);

    mpf_class reference = sqrt(two);
    std::cout << "sqrt() result: " << reference << '\n';
    return 0;
}
