/*
 * Copyright (c) 2026
 *      Nakata, Maho
 *      All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include "Rdot_common.hpp"

mpf_class _Rdot(int64_t n, mpf_class *dx, int64_t incx, mpf_class *dy, int64_t incy) {
    if (incx != 1 || incy != 1) {
        std::cerr << "Increments other than 1 are not supported." << std::endl;
        exit(EXIT_FAILURE);
    }

    const int64_t unrolled_n = n - (n % 4);
    mpf_class result = 0.0;

#pragma omp parallel
    {
        mpf_class acc0 = 0.0;
        mpf_class acc1 = 0.0;
        mpf_class acc2 = 0.0;
        mpf_class acc3 = 0.0;
        mpf_class templ;

#pragma omp for schedule(static)
        for (int64_t i = 0; i < unrolled_n; i += 4) {
            templ = dx[i] * dy[i];
            acc0 += templ;

            templ = dx[i + 1] * dy[i + 1];
            acc1 += templ;

            templ = dx[i + 2] * dy[i + 2];
            acc2 += templ;

            templ = dx[i + 3] * dy[i + 3];
            acc3 += templ;
        }

#pragma omp for schedule(static)
        for (int64_t i = unrolled_n; i < n; ++i) {
            templ = dx[i] * dy[i];
            acc0 += templ;
        }

        acc0 += acc1;
        acc2 += acc3;
        acc0 += acc2;

#pragma omp critical
        result += acc0;
    }

    return result;
}

int main(int argc, char **argv) {
    return rdot_gmp_bench::run_class_rdot_benchmark(argc, argv, _Rdot);
}
