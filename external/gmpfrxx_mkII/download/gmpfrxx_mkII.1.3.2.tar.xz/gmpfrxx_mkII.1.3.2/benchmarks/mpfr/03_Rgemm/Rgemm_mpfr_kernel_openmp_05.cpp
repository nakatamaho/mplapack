/*
 * Copyright (c) 2026
 *      Nakata, Maho
 *      All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 */

#include "Rgemm_common.hpp"

namespace {

constexpr int RgemmPanelSize = 4;

void set_scratch_precision_zero(mpfr_class &value, mpfr_prec_t precision) {
    value.set_prec(precision);
    value = 0;
}

struct RgemmPanelScratch {
    explicit RgemmPanelScratch(mpfr_prec_t precision) {
        set_scratch_precision_zero(prod, precision);
        for (int i = 0; i < RgemmPanelSize; ++i) {
            set_scratch_precision_zero(scaled_b[i], precision);
        }
    }

    mpfr_class scaled_b[RgemmPanelSize];
    mpfr_class prod;
};

int64_t panel_width(int64_t n, int64_t j0) {
    const int64_t remaining = n - j0;
    return remaining < RgemmPanelSize ? remaining : RgemmPanelSize;
}

void rgemm_panel(int64_t m, int64_t k, int64_t n, int64_t j0, const mpfr_class &alpha, const mpfr_class *A, int64_t lda, const mpfr_class *B, int64_t ldb, const mpfr_class &beta, mpfr_class *C, int64_t ldc, RgemmPanelScratch &scratch) {
    const int64_t jb = panel_width(n, j0);

    for (int64_t i = 0; i < m; ++i) {
        for (int64_t jj = 0; jj < jb; ++jj) {
            C[i + (j0 + jj) * ldc] *= beta;
        }
    }

    for (int64_t l = 0; l < k; ++l) {
        for (int64_t jj = 0; jj < jb; ++jj) {
            scratch.scaled_b[jj] = alpha;
            scratch.scaled_b[jj] *= B[l + (j0 + jj) * ldb];
        }

        for (int64_t i = 0; i < m; ++i) {
            const mpfr_class &a = A[i + l * lda];
            for (int64_t jj = 0; jj < jb; ++jj) {
                scratch.prod = scratch.scaled_b[jj];
                scratch.prod *= a;
                C[i + (j0 + jj) * ldc] += scratch.prod;
            }
        }
    }
}

} // namespace

void _Rgemm(int64_t m, int64_t k, int64_t n, const mpfr_class &alpha, const mpfr_class *A, int64_t lda, const mpfr_class *B, int64_t ldb, const mpfr_class &beta, mpfr_class *C, int64_t ldc) {
#pragma omp parallel
    {
        RgemmPanelScratch scratch(alpha.get_prec());

#pragma omp for schedule(static)
        for (int64_t j = 0; j < n; j += RgemmPanelSize) {
            rgemm_panel(m, k, n, j, alpha, A, lda, B, ldb, beta, C, ldc, scratch);
        }
    }
}

int main(int argc, char **argv) {
    return run_class_rgemm_benchmark(argc, argv, _Rgemm);
}
