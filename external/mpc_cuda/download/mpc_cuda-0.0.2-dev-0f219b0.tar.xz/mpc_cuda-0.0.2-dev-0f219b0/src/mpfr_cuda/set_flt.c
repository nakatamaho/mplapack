/* CUDA-adapted from MPFR by tools/cudafy_mpfr.py. */
/* cu_mpfr_set_flt -- convert a machine single precision float to mpfr_t

Copyright 2009-2025 Free Software Foundation, Inc.
Contributed by the Pascaline and Caramba projects, INRIA.

This file is part of the GNU MPFR Library.

The GNU MPFR Library is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 3 of the License, or (at your
option) any later version.

The GNU MPFR Library is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
License for more details.

You should have received a copy of the GNU Lesser General Public License
along with the GNU MPFR Library; see the file COPYING.LESSER.
If not, see <https://www.gnu.org/licenses/>. */

#include "mpfr-impl.h"

__host__ __device__
int
cu_mpfr_set_flt (mpfr_ptr r, float f, mpfr_rnd_t rnd_mode)
{
  /* we convert f to double precision and use cu_mpfr_set_d;
     NaN and infinities should be preserved (except the sign bit for NaN),
     and all single precision numbers are exactly representable in the double
     format, thus the conversion is always exact */
  return cu_mpfr_set_d (r, (double) f, rnd_mode);
}

