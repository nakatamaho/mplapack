/* CUDA-adapted from MPC by tools/cudafy_mpc.py. */
/* cu_mpc_pow_fr -- Raise a complex number to a floating-point power.

Copyright (C) 2009, 2011, 2012 INRIA

This file is part of GNU MPC.

GNU MPC is free software; you can redistribute it and/or modify it under
the terms of the GNU Lesser General Public License as published by the
Free Software Foundation; either version 3 of the License, or (at your
option) any later version.

GNU MPC is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for
more details.

You should have received a copy of the GNU Lesser General Public License
along with this program. If not, see http://www.gnu.org/licenses/ .
*/

#include "mpc-impl.h"

__host__ __device__
int
cu_mpc_pow_fr (mpc_ptr z, mpc_srcptr x, mpfr_srcptr y, mpc_rnd_t rnd)
{
  mpc_t yy;
  int inex;

  /* avoid copying the significand of y by copying only the struct */
  mpc_realref(yy)[0] = y[0];
  cu_mpfr_init2 (mpc_imagref(yy), MPFR_PREC_MIN);
  cu_mpfr_set_ui (mpc_imagref(yy), 0, MPFR_RNDN);
  inex = mpc_pow (z, x, yy, rnd);
  cu_mpfr_clear (mpc_imagref(yy));
  return inex;
}

