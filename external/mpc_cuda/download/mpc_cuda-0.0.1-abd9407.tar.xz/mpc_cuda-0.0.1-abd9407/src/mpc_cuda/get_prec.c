/* CUDA-adapted from MPC by tools/cudafy_mpc.py. */
/* cu_mpc_get_prec -- returns the common precision of real and imaginary part, or 0 if they differ

Copyright (C) 2007, 2009, 2010 INRIA

This file is part of GNU MPC.

GNU MPC is free software; you can redistribute it and/or modify it under
the terms of the GNU Lesser General Public License as published by the
Free Software Foundation; either version 3 of the License, or (at your
option) any later version.

GNU MPC is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for
more details.

You should have received a copy of the GNU Lesser General Public License
along with this program. If not, see http://www.gnu.org/licenses/ .
*/

#include "mpc-impl.h"

__host__ __device__
mpfr_prec_t
cu_mpc_get_prec (mpc_srcptr x)
{
  mpfr_prec_t precre = MPC_PREC_RE (x);
  return (MPC_PREC_IM (x) == precre ? precre : 0);
}
