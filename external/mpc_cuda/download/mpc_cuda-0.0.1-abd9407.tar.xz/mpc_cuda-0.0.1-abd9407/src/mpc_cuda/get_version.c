/* CUDA-adapted from MPC by tools/cudafy_mpc.py. */
/* cu_mpc_get_version -- MPC version

Copyright (C) 2008, 2009, 2010, 2011, 2012, 2017, 2018, 2020, 2022, 2023, 2026 INRIA

This file is part of GNU MPC.

GNU MPC is free software; you can redistribute it and/or modify it under
the terms of the GNU Lesser General Public License as published by the
Free Software Foundation; either version 3 of the License, or (at your
option) any later version.

GNU MPC is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for
more details.

You should have received a copy of the GNU Lesser General Public License
along with this program. If not, see http://www.gnu.org/licenses/ .
*/

#include "mpc-impl.h"

__host__ __device__
const char *
cu_mpc_get_version (void)
{
  return "1.4.1";
}
