/* CUDA-adapted from MPFR by tools/cudafy_mpfr.py. */
/* mpfr_jn_asympt, mpfr_yn_asympt -- shared code for cu_mpfr_jn and cu_mpfr_yn

Copyright 2007-2025 Free Software Foundation, Inc.
Contributed by the Pascaline and Caramba projects, INRIA.

This file is part of the GNU MPFR Library.

The GNU MPFR Library is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 3 of the License, or (at your
option) any later version.

The GNU MPFR Library is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
License for more details.

You should have received a copy of the GNU Lesser General Public License
along with the GNU MPFR Library; see the file COPYING.LESSER.
If not, see <https://www.gnu.org/licenses/>. */

#ifdef MPFR_JN
# define FUNCTION mpfr_jn_asympt
#else
# ifdef MPFR_YN
#  define FUNCTION mpfr_yn_asympt
# else
#  error "neither MPFR_JN nor MPFR_YN is defined"
# endif
#endif

/* Implements asymptotic expansion for jn or yn (formulae 9.2.5 and 9.2.6
   from Abramowitz & Stegun).
   Assumes |z| > p log(2)/2, where p is the target precision
   (z can be negative only for jn).
   Return 0 if the expansion does not converge enough (the value 0 as inexact
   flag should not happen for normal input).
   Note: for MPFR_RNDF, it returns 0 if the expansion failed, and a non-zero
   value otherwise (with no other meaning).
*/
__host__ __device__
static int
FUNCTION (mpfr_ptr res, long n, mpfr_srcptr z, mpfr_rnd_t r)
{
  mpfr_t s, c, P, Q, t, iz, err_t, err_s, err_u;
  mpfr_prec_t w;
  long k;
  int inex, stop, diverge = 0;
  mpfr_exp_t err2, err;
  MPFR_ZIV_DECL (loop);

  cu_mpfr_init2 (c, 64);

  /* The terms of the asymptotic expansion grow like mu^(2k)/(8z)^(2k), where
     mu = 4n^2, thus we need mu < 8|z| so that it converges,
     i.e., n^2/2 < |z| */
  MPFR_ASSERTD (n >= 0);
  cu_mpfr_set_ui (c, n, MPFR_RNDU);
  cu_mpfr_mul_ui (c, c, n, MPFR_RNDU);
  cu_mpfr_div_2ui (c, c, 1, MPFR_RNDU);
  if (cu_mpfr_cmpabs (c, z) >= 0)
    {
      cu_mpfr_clear (c);
      return 0; /* asymptotic expansion failed */
    }

  w = MPFR_PREC(res) + MPFR_INT_CEIL_LOG2(MPFR_PREC(res)) + 4;

  MPFR_ZIV_INIT (loop, w);
  for (;;)
    {
      int ok = 0;

      cu_mpfr_set_prec (c, w);
      cu_mpfr_init2 (s, w);
      cu_mpfr_init2 (P, w);
      cu_mpfr_init2 (Q, w);
      cu_mpfr_init2 (t, w);
      cu_mpfr_init2 (iz, w);
      cu_mpfr_init2 (err_t, 31);
      cu_mpfr_init2 (err_s, 31);
      cu_mpfr_init2 (err_u, 31);

      /* Approximate sin(z) and cos(z). In the following, err <= k means that
         the approximate value y and the true value x are related by
         y = x * (1 + u)^k with |u| <= 2^(-w), following Higham's method. */
      cu_mpfr_sin_cos (s, c, z, MPFR_RNDN);
      if (MPFR_IS_NEG(z))
        cu_mpfr_neg (s, s, MPFR_RNDN); /* compute jn/yn(|z|), fix sign later */
      /* The absolute error on s/c is bounded by 1/2 ulp(1/2) <= 2^(-w-1). */
      cu_mpfr_add (t, s, c, MPFR_RNDN);
      cu_mpfr_sub (c, s, c, MPFR_RNDN);
      cu_mpfr_swap (s, t);
      /* now s approximates sin(z)+cos(z), and c approximates sin(z)-cos(z),
         with total absolute error bounded by 2^(1-w). */

      /* if s or c is zero, MPFR_GET_EXP will fail below */
      if (MPFR_IS_ZERO(s) || MPFR_IS_ZERO(c))
        goto clear; /* with ok=0 */

      /* precompute 1/(8|z|) */
      cu_mpfr_si_div (iz, MPFR_IS_POS(z) ? 1 : -1, z, MPFR_RNDN);   /* err <= 1 */
      cu_mpfr_div_2ui (iz, iz, 3, MPFR_RNDN);

      /* compute P and Q */
      cu_mpfr_set_ui (P, 1, MPFR_RNDN);
      cu_mpfr_set_ui (Q, 0, MPFR_RNDN);
      cu_mpfr_set_ui (t, 1, MPFR_RNDN); /* current term */
      cu_mpfr_set_ui (err_t, 0, MPFR_RNDN); /* error on t */
      cu_mpfr_set_ui (err_s, 0, MPFR_RNDN); /* error on P and Q (sum of errors) */
      for (k = 1, stop = 0; stop < 4; k++)
        {
          /* compute next term: t(k)/t(k-1) = (2n+2k-1)(2n-2k+1)/(8kz) */
          MPFR_LOG_MSG (("loop (k,stop) = (%ld,%d)\n", k, stop));
          cu_mpfr_mul_si (t, t, 2 * (n + k) - 1, MPFR_RNDN); /* err <= err_k + 1 */
          cu_mpfr_mul_si (t, t, 2 * (n - k) + 1, MPFR_RNDN); /* err <= err_k + 2 */
          cu_mpfr_div_ui (t, t, k, MPFR_RNDN);               /* err <= err_k + 3 */
          cu_mpfr_mul (t, t, iz, MPFR_RNDN);                 /* err <= err_k + 5 */
          /* the relative error on t is bounded by (1+u)^(5k)-1, which is
             bounded by 6ku for 6ku <= 0.02: first |5 log(1+u)| <= |5.5u|
             for |u| <= 0.15, then |exp(5.5u)-1| <= 6u for |u| <= 0.02. */
          cu_mpfr_mul_ui (err_t, t, 6 * k, MPFR_IS_POS(t) ? MPFR_RNDU : MPFR_RNDD);
          cu_mpfr_abs (err_t, err_t, MPFR_RNDN); /* exact */
          /* the absolute error on t is bounded by err_t * 2^(-w) */
          cu_mpfr_abs (err_u, t, MPFR_RNDU);
          cu_mpfr_mul_2ui (err_u, err_u, w, MPFR_RNDU); /* t * 2^w */
          cu_mpfr_add (err_u, err_u, err_t, MPFR_RNDU); /* max|t| * 2^w */
          if (stop >= 2)
            {
              /* take into account the neglected terms: t * 2^w */
              cu_mpfr_div_2ui (err_s, err_s, w, MPFR_RNDU);
              if (MPFR_IS_POS(t))
                cu_mpfr_add (err_s, err_s, t, MPFR_RNDU);
              else
                cu_mpfr_sub (err_s, err_s, t, MPFR_RNDU);
              cu_mpfr_mul_2ui (err_s, err_s, w, MPFR_RNDU);
              stop ++;
            }
          /* if k is odd, add to Q, otherwise to P */
          else if (k & 1)
            {
              /* if k = 1 mod 4, add, otherwise subtract */
              if ((k & 2) == 0)
                cu_mpfr_add (Q, Q, t, MPFR_RNDN);
              else
                cu_mpfr_sub (Q, Q, t, MPFR_RNDN);
              /* check if the next term is smaller than ulp(Q): if EXP(err_u)
                 <= EXP(Q), since the current term is bounded by
                 err_u * 2^(-w), it is bounded by ulp(Q) */
              if (MPFR_GET_EXP (err_u) <= MPFR_GET_EXP (Q))
                stop ++;
              else
                stop = 0;
            }
          else
            {
              /* if k = 0 mod 4, add, otherwise subtract */
              if ((k & 2) == 0)
                cu_mpfr_add (P, P, t, MPFR_RNDN);
              else
                cu_mpfr_sub (P, P, t, MPFR_RNDN);
              /* check if the next term is smaller than ulp(P) */
              if (MPFR_GET_EXP (err_u) <= MPFR_GET_EXP (P))
                stop ++;
              else
                stop = 0;
            }
          cu_mpfr_add (err_s, err_s, err_t, MPFR_RNDU);
          /* the sum of the rounding errors on P and Q is bounded by
             err_s * 2^(-w) */

          /* stop when start to diverge */
          if (stop < 2 &&
              ((MPFR_IS_POS(z) && cu_mpfr_cmp_ui (z, (k + 1) / 2) < 0) ||
               (MPFR_IS_NEG(z) && cu_mpfr_cmp_si (z, - ((k + 1) / 2)) > 0)))
            {
              /* if we have to stop the series because it diverges, then
                 increasing the precision will most probably fail, since
                 we will stop to the same point, and thus compute a very
                 similar approximation */
              diverge = 1;
              stop = 2; /* force stop */
            }
        }
      /* the sum of the total errors on P and Q is bounded by err_s * 2^(-w) */

      /* Now combine: the sum of the rounding errors on P and Q is bounded by
         err_s * 2^(-w), and the absolute error on s/c is bounded by 2^(1-w) */
      if ((n & 1) == 0) /* n even: P * (sin + cos) + Q (cos - sin) for jn
                                   Q * (sin + cos) + P (sin - cos) for yn */
        {
#ifdef MPFR_JN
          cu_mpfr_mul (c, c, Q, MPFR_RNDN); /* Q * (sin - cos) */
          cu_mpfr_mul (s, s, P, MPFR_RNDN); /* P * (sin + cos) */
#else
          cu_mpfr_mul (c, c, P, MPFR_RNDN); /* P * (sin - cos) */
          cu_mpfr_mul (s, s, Q, MPFR_RNDN); /* Q * (sin + cos) */
#endif
          err = MPFR_GET_EXP (c);
          if (MPFR_GET_EXP (s) > err)
            err = MPFR_EXP (s);
#ifdef MPFR_JN
          cu_mpfr_sub (s, s, c, MPFR_RNDN);
#else
          cu_mpfr_add (s, s, c, MPFR_RNDN);
#endif
        }
      else /* n odd: P * (sin - cos) + Q (cos + sin) for jn,
                     Q * (sin - cos) - P (cos + sin) for yn */
        {
#ifdef MPFR_JN
          cu_mpfr_mul (c, c, P, MPFR_RNDN); /* P * (sin - cos) */
          cu_mpfr_mul (s, s, Q, MPFR_RNDN); /* Q * (sin + cos) */
#else
          cu_mpfr_mul (c, c, Q, MPFR_RNDN); /* Q * (sin - cos) */
          cu_mpfr_mul (s, s, P, MPFR_RNDN); /* P * (sin + cos) */
#endif
          err = MPFR_GET_EXP (c);
          if (MPFR_GET_EXP (s) > err)
            err = MPFR_EXP (s);
#ifdef MPFR_JN
          cu_mpfr_add (s, s, c, MPFR_RNDN);
#else
          cu_mpfr_sub (s, c, s, MPFR_RNDN);
#endif
        }
      if (MPFR_IS_ZERO(s))
        goto clear; /* with ok=0 */
      ok = 1;
      if ((n & 2) != 0)
        cu_mpfr_neg (s, s, MPFR_RNDN);
      if (MPFR_GET_EXP (s) > err)
        err = MPFR_EXP (s);
      /* the absolute error on s is bounded by P*err(s/c) + Q*err(s/c)
         + err(P)*(s/c) + err(Q)*(s/c) + 3 * 2^(err - w - 1)
         <= (|P|+|Q|) * 2^(1-w) + err_s * 2^(1-w) + 2^err * 2^(1-w),
         since |c|, |old_s| <= 2. */
      err2 = (MPFR_GET_EXP (P) >= MPFR_GET_EXP (Q))
        ? MPFR_EXP (P) + 2 : MPFR_EXP (Q) + 2;
      /* (|P| + |Q|) * 2^(1 - w) <= 2^(err2 - w) */
      err = MPFR_GET_EXP (err_s) >= err ? MPFR_EXP (err_s) + 2 : err + 2;
      /* err_s * 2^(1-w) + 2^old_err * 2^(1-w) <= 2^err * 2^(-w) */
      err2 = (err >= err2) ? err + 1 : err2 + 1;
      /* now the absolute error on s is bounded by 2^(err2 - w) */

      /* multiply by sqrt(1/(Pi*z)) */
      cu_mpfr_const_pi (c, MPFR_RNDN);     /* Pi, err <= 1 */
      cu_mpfr_mul (c, c, z, MPFR_RNDN);    /* err <= 2 */
      cu_mpfr_si_div (c, MPFR_IS_POS(z) ? 1 : -1, c, MPFR_RNDN); /* err <= 3 */
      cu_mpfr_sqrt (c, c, MPFR_RNDN);      /* err<=5/2, thus the absolute error is
                                          bounded by 3*u*|c| for |u| <= 0.25 */
      cu_mpfr_mul (err_t, c, s, MPFR_SIGN(c)==MPFR_SIGN(s) ? MPFR_RNDU : MPFR_RNDD);
      cu_mpfr_abs (err_t, err_t, MPFR_RNDU);
      cu_mpfr_mul_ui (err_t, err_t, 3, MPFR_RNDU);
      /* 3*2^(-w)*|old_c|*|s| [see below] is bounded by err_t * 2^(-w) */
      err2 += MPFR_GET_EXP (c);
      /* |old_c| * 2^(err2 - w) [see below] is bounded by 2^(err2-w) */
      cu_mpfr_mul (c, c, s, MPFR_RNDN);    /* the absolute error on c is bounded by
                                          1/2 ulp(c) + 3*2^(-w)*|old_c|*|s|
                                          + |old_c| * 2^(err2 - w) */
      /* compute err_t * 2^(-w) + 1/2 ulp(c) = (err_t + 2^EXP(c)) * 2^(-w) */
      err = (MPFR_GET_EXP (err_t) > MPFR_GET_EXP (c)) ?
        MPFR_EXP (err_t) + 1 : MPFR_EXP (c) + 1;
      /* err_t * 2^(-w) + 1/2 ulp(c) <= 2^(err - w) */
      /* now err_t * 2^(-w) bounds 1/2 ulp(c) + 3*2^(-w)*|old_c|*|s| */
      err = (err >= err2) ? err + 1 : err2 + 1;
      /* the absolute error on c is bounded by 2^(err - w) */

      err -= MPFR_GET_EXP (c);

    clear:
      cu_mpfr_clear (s);
      cu_mpfr_clear (P);
      cu_mpfr_clear (Q);
      cu_mpfr_clear (t);
      cu_mpfr_clear (iz);
      cu_mpfr_clear (err_t);
      cu_mpfr_clear (err_s);
      cu_mpfr_clear (err_u);

      if (ok && MPFR_LIKELY (MPFR_CAN_ROUND (c, w - err, MPFR_PREC(res), r)))
        break;
      if (diverge != 0)
        {
          MPFR_ZIV_FREE (loop);
          cu_mpfr_clear (c);
          return 0; /* means that the asymptotic expansion failed */
        }
      MPFR_ZIV_NEXT (loop, w);
    }
  MPFR_ZIV_FREE (loop);

  inex = cu_mpfr_set4 (res, c, r, MPFR_IS_POS (z) || (n & 1) == 0 ?
                    MPFR_SIGN (c) : - MPFR_SIGN (c));
  cu_mpfr_clear (c);

  /* for RNDF, cu_mpfr_set or cu_mpfr_neg may return 0, but if we return 0, it
     would mean the asymptotic expansion failed, thus we return 1 instead */
  return (r != MPFR_RNDF) ? inex : 1;
}
