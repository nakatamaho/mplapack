/* CUDA-adapted from MPFR by tools/cudafy_mpfr.py. */
/* cu_mpfr_const_catalan -- compute Catalan's constant.

Copyright 2005-2025 Free Software Foundation, Inc.
Contributed by the Pascaline and Caramba projects, INRIA.

This file is part of the GNU MPFR Library.

The GNU MPFR Library is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 3 of the License, or (at your
option) any later version.

The GNU MPFR Library is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
License for more details.

You should have received a copy of the GNU Lesser General Public License
along with the GNU MPFR Library; see the file COPYING.LESSER.
If not, see <https://www.gnu.org/licenses/>. */

#define MPFR_NEED_LONGLONG_H
#include "mpfr-impl.h"

/* Declare the cache */
MPFR_DECL_INIT_CACHE (cu___gmpfr_cache_const_catalan, cu_mpfr_const_catalan_internal)

/* Set User Interface */
#undef cu_mpfr_const_catalan
__host__ __device__
int
cu_mpfr_const_catalan (mpfr_ptr x, mpfr_rnd_t rnd_mode) {
  return mpfr_const_catalan_cuda (x, rnd_mode);
}

/* return T, Q such that T/Q = sum(k!^2/(2k)!/(2k+1)^2, k=n1..n2-1) */
__host__ __device__
static void
S (mpz_t T, mpz_t P, mpz_t Q, unsigned long n1, unsigned long n2)
{
  if (n2 == n1 + 1)
    {
      if (n1 == 0)
        {
          cu_mpz_set_ui (P, 1);
          cu_mpz_set_ui (Q, 1);
        }
      else
        {
          cu_mpz_set_ui (P, 2 * n1 - 1);
          cu_mpz_mul_ui (P, P, n1);
          cu_mpz_ui_pow_ui (Q, 2 * n1 + 1, 2);
          cu_mpz_mul_2exp (Q, Q, 1);
        }
      cu_mpz_set (T, P);
    }
  else
    {
      unsigned long m = (n1 + n2) / 2;
      mpz_t T2, P2, Q2;
      S (T, P, Q, n1, m);
      cu_mpz_init (T2);
      cu_mpz_init (P2);
      cu_mpz_init (Q2);
      S (T2, P2, Q2, m, n2);
      cu_mpz_mul (T, T, Q2);
      cu_mpz_mul (T2, T2, P);
      cu_mpz_add (T, T, T2);
      cu_mpz_mul (P, P, P2);
      cu_mpz_mul (Q, Q, Q2);
      cu_mpz_clear (T2);
      cu_mpz_clear (P2);
      cu_mpz_clear (Q2);
    }
}

/* Don't need to save/restore exponent range: the cache does it.
   Catalan's constant is G = sum((-1)^k/(2*k+1)^2, k=0..infinity).
   We compute it using formula (31) of Victor Adamchik's page
   "33 representations for Catalan's constant"
   https://web.archive.org/web/20090624123133/http://www-2.cs.cmu.edu/~adamchik/articles/catalan/catalan.htm

   G = Pi/8*log(2+sqrt(3)) + 3/8*sum(k!^2/(2k)!/(2k+1)^2,k=0..infinity)
*/
__host__ __device__
int
cu_mpfr_const_catalan_internal (mpfr_ptr g, mpfr_rnd_t rnd_mode)
{
  mpfr_t x, y, z;
  mpz_t T, P, Q;
  mpfr_prec_t pg, p;
  int inex;
  MPFR_ZIV_DECL (loop);
  MPFR_GROUP_DECL (group);

  MPFR_LOG_FUNC (("rnd_mode=%d", rnd_mode),
    ("g[%Pd]=%.*Rg inex=%d", cu_mpfr_get_prec (g), mpfr_log_prec, g, inex));

  /* Here are the WC (max prec = 100.000.000)
     Once we have found a chain of 11, we only look for bigger chain.
     Found 3 '1' at 0
     Found 5 '1' at 9
     Found 6 '0' at 34
     Found 9 '1' at 176
     Found 11 '1' at 705
     Found 12 '0' at 913
     Found 14 '1' at 12762
     Found 15 '1' at 152561
     Found 16 '0' at 171725
     Found 18 '0' at 525355
     Found 20 '0' at 529245
     Found 21 '1' at 6390133
     Found 22 '0' at 7806417
     Found 25 '1' at 11936239
     Found 27 '1' at 51752950
  */
  pg = MPFR_PREC (g);
  p = pg + MPFR_INT_CEIL_LOG2 (pg) + 7;

  MPFR_GROUP_INIT_3 (group, p, x, y, z);
  cu_mpz_init (T);
  cu_mpz_init (P);
  cu_mpz_init (Q);

  MPFR_ZIV_INIT (loop, p);
  for (;;) {
    cu_mpfr_sqrt_ui (x, 3, MPFR_RNDU);
    cu_mpfr_add_ui (x, x, 2, MPFR_RNDU);
    cu_mpfr_log (x, x, MPFR_RNDU);
    cu_mpfr_const_pi (y, MPFR_RNDU);
    cu_mpfr_mul (x, x, y, MPFR_RNDN);
    S (T, P, Q, 0, (p - 1) / 2);
    cu_mpz_mul_ui (T, T, 3);
    cu_mpfr_set_z (y, T, MPFR_RNDU);
    cu_mpfr_set_z (z, Q, MPFR_RNDD);
    cu_mpfr_div (y, y, z, MPFR_RNDN);
    cu_mpfr_add (x, x, y, MPFR_RNDN);
    cu_mpfr_div_2ui (x, x, 3, MPFR_RNDN);

    if (MPFR_LIKELY (MPFR_CAN_ROUND (x, p - 5, pg, rnd_mode)))
      break;

    MPFR_ZIV_NEXT (loop, p);
    MPFR_GROUP_REPREC_3 (group, p, x, y, z);
  }
  MPFR_ZIV_FREE (loop);
  inex = cu_mpfr_set (g, x, rnd_mode);

  MPFR_GROUP_CLEAR (group);
  cu_mpz_clear (T);
  cu_mpz_clear (P);
  cu_mpz_clear (Q);

  return inex;
}
