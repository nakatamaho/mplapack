/* CUDA-adapted from MPFR by tools/cudafy_mpfr.py. */
/* cu_mpfr_urandomb (rop, state, nbits) -- Generate a uniform pseudorandom
   real number between 0 (inclusive) and 1 (exclusive) of size NBITS,
   using STATE as the random state previously initialized by a call to
   gmp_randinit_lc_2exp_size().

Copyright 2000-2004, 2006-2025 Free Software Foundation, Inc.
Contributed by the Pascaline and Caramba projects, INRIA.

This file is part of the GNU MPFR Library.

The GNU MPFR Library is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 3 of the License, or (at your
option) any later version.

The GNU MPFR Library is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
License for more details.

You should have received a copy of the GNU Lesser General Public License
along with the GNU MPFR Library; see the file COPYING.LESSER.
If not, see <https://www.gnu.org/licenses/>. */


#define MPFR_NEED_LONGLONG_H
#include "mpfr-impl.h"

/* generate nbits random bits into mp[], assuming mp was allocated to contain
   a sufficient number of limbs */
__host__ __device__
void
cu_mpfr_rand_raw (mpfr_limb_ptr mp, gmp_randstate_t rstate,
               mpfr_prec_t nbits)
{
  mpz_t z;

  MPFR_ASSERTN (nbits >= 1);
  /* Check for integer overflow (unless mp_bitcnt_t is signed,
     but according to the GMP manual, this shouldn't happen).
     Note: mp_bitcnt_t has been introduced in GMP 5.0.0. */
  MPFR_ASSERTN ((mp_bitcnt_t) -1 < 0 || nbits <= (mp_bitcnt_t) -1);
  cu_mpz_init (z);
  mpz_urandomb (z, rstate, nbits);
  MPN_COPY(mp, PTR(z), MPFR_PREC2LIMBS (nbits));
  cu_mpz_clear (z);
}

__host__ __device__
int
cu_mpfr_urandomb (mpfr_ptr rop, gmp_randstate_t rstate)
{
  mpfr_limb_ptr rp;
  mpfr_prec_t nbits;
  mp_size_t nlimbs;
  mp_size_t k; /* number of high zero limbs */
  mpfr_exp_t exp;
  int cnt;

  rp = MPFR_MANT (rop);
  nbits = MPFR_PREC (rop);
  nlimbs = MPFR_LIMB_SIZE (rop);
  MPFR_SET_POS (rop);
  cnt = nlimbs * GMP_NUMB_BITS - nbits;

  /* Uniform non-normalized significand */
  /* generate exactly nbits so that the random generator stays in the same
     state, independent of the machine word size GMP_NUMB_BITS */
  cu_mpfr_rand_raw (rp, rstate, nbits);
  if (MPFR_LIKELY (cnt != 0)) /* this will put the low bits to zero */
    cu_mpn_lshift (rp, rp, nlimbs, cnt);

  /* Count the null significant limbs and remaining limbs */
  exp = 0;
  k = 0;
  while (nlimbs != 0 && rp[nlimbs - 1] == 0)
    {
      k ++;
      nlimbs --;
      exp -= GMP_NUMB_BITS;
    }

  if (MPFR_LIKELY (nlimbs != 0)) /* otherwise value is zero */
    {
      count_leading_zeros (cnt, rp[nlimbs - 1]);
      /* Normalization */
      exp -= cnt;
      if (MPFR_UNLIKELY (! MPFR_EXP_IN_RANGE (exp)))
        {
          /* If the exponent is not in the current exponent range, we
             choose to return a NaN as this is probably a user error.
             Indeed this can happen only if the exponent range has been
             reduced to a very small interval and/or the precision is
             huge (very unlikely). */
          MPFR_SET_NAN (rop);
          cu___gmpfr_flags |= MPFR_FLAGS_NAN; /* Can't use MPFR_RET_NAN */
          return 1;
        }
      MPFR_SET_EXP (rop, exp);
      if (cnt != 0)
        cu_mpn_lshift (rp + k, rp, nlimbs, cnt);
      else if (k != 0)
        cu_mpn_copyd (rp + k, rp, nlimbs);
      if (k != 0)
        MPN_ZERO (rp, k);
    }
  else
    MPFR_SET_ZERO (rop);

  return 0;
}
