/* CUDA-adapted from MPFR by tools/cudafy_mpfr.py. */
/* cu_mpfr_set_default_rounding_mode -- set the default rounding mode
   cu_mpfr_get_default_rounding_mode -- get the default rounding mode

Copyright 1999, 2001, 2004-2025 Free Software Foundation, Inc.
Contributed by the Pascaline and Caramba projects, INRIA.

This file is part of the GNU MPFR Library.

The GNU MPFR Library is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 3 of the License, or (at your
option) any later version.

The GNU MPFR Library is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
License for more details.

You should have received a copy of the GNU Lesser General Public License
along with the GNU MPFR Library; see the file COPYING.LESSER.
If not, see <https://www.gnu.org/licenses/>. */

#include "mpfr-impl.h"

MPFR_THREAD_VAR (mpfr_rnd_t, cu___gmpfr_default_rounding_mode, MPFR_RNDN)

__host__ __device__
void
cu_mpfr_set_default_rounding_mode (mpfr_rnd_t rnd_mode)
{
  if (rnd_mode >= MPFR_RNDN && rnd_mode < MPFR_RND_MAX)
    cu___gmpfr_default_rounding_mode = rnd_mode;
}

#undef cu_mpfr_get_default_rounding_mode
__host__ __device__
mpfr_rnd_t
cu_mpfr_get_default_rounding_mode (void)
{
  return cu___gmpfr_default_rounding_mode;
}
