/*
 * tests/qd_test.cpp
 *
 * This work was supported by the Director, Office of Science, Division
 * of Mathematical, Information, and Computational Sciences of the
 * U.S. Department of Energy under contract number DE-AC03-76SF00098.
 *
 * Copyright (c) 2000-2001
 *
 * This contains some simple tests to sanity check the double-double
 * and quad-double library.
 */

#include <cstdlib>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <iostream>
#include <iomanip>
#include <limits>
#include <algorithm>
#include <sstream>
#include <stdexcept>
#include <string>
#include <type_traits>
#include <vector>
#include <qd/qd_real.h>
#include <qd/td_real.h>
#ifdef QD_HAVE_EDD_REAL
#include <qd/edd_real.h>
#endif
#include <qd/inline.h>
#include <qd/fpu.h>

using std::cout;
using std::cerr;
using std::endl;

using std::abs;
using std::sqrt;
using std::strcmp;
using std::exit;

// Global flags passed to the main program.
static bool flag_test_dd = false;
static bool flag_test_td = false;
static bool flag_test_qd = false;
#ifdef QD_HAVE_EDD_REAL
static bool flag_test_edd = false;
#endif
bool flag_verbose = false;

bool print_result(bool result) {
  if (result)
    cout << "Test passed." << endl;
  else
    cout << "Test FAILED." << endl;
  return result;
}

template <class T>
class TestSuite {
  static const int double_digits;
public:
  bool test1();
  bool test2();
  bool test3();
  bool test4();
  bool test5();
  bool test6();
  bool test7();
  bool test8();
  bool test9();
  bool testall();
};

template <class T>
const int TestSuite<T>::double_digits = 6;

td_real polyeval(const td_real *c, int n, const td_real &x) {
  std::vector<qd_real> qc(n + 1);

  for (int i = 0; i <= n; i++) {
    qc[i] = to_qd_real(c[i]);
  }

  qd_real y = ::polyeval(qc.data(), n, to_qd_real(x));
  return to_td_real(y);
}

td_real polyroot(const td_real *c, int n, const td_real &x0,
    int max_iter = 64, double thresh = 0.0) {
  std::vector<qd_real> qc(n + 1);

  for (int i = 0; i <= n; i++) {
    qc[i] = to_qd_real(c[i]);
  }

  qd_real x = ::polyroot(qc.data(), n, to_qd_real(x0), max_iter, thresh);
  return to_td_real(x);
}

namespace {

template <class I>
typename std::enable_if<qd::is_supported_signed_integral<I>::value,
                        std::int64_t>::type
integral_expected(I value) {
  return static_cast<std::int64_t>(value);
}

template <class I>
typename std::enable_if<qd::is_supported_unsigned_integral<I>::value,
                        std::uint64_t>::type
integral_expected(I value) {
  return static_cast<std::uint64_t>(value);
}

template <class Real, class I>
bool check_integral_conversion_case(const char *real_name,
                                    const char *integer_name, I value) {
  static_assert(qd::is_supported_integral<I>::value,
                "integer test case must use a supported non-bool integral");

  const Real expected(integral_expected(value));
  const Real constructed(value);
  Real assigned;
  assigned = value;

  const bool pass = (constructed == expected) && (assigned == expected);
  if (!pass && flag_verbose) {
    cout << real_name << " " << integer_name
         << " integral conversion mismatch" << endl;
  }
  return pass;
}

template <class Real>
bool test_integral_template_conversions(const char *real_name,
                                        const char *test_name) {
  cout << endl;
  cout << test_name << "  (" << real_name
       << " integral template constructors / assignments)." << endl;

  static_assert(!qd::is_supported_integral<bool>::value,
                "bool must not be captured by the integral template path");

  bool pass = true;
  pass &= check_integral_conversion_case<Real>(
      real_name, "int32_t", static_cast<std::int32_t>(-123456789));
  pass &= check_integral_conversion_case<Real>(
      real_name, "uint32_t", static_cast<std::uint32_t>(0xffffffffu));
  pass &= check_integral_conversion_case<Real>(
      real_name, "int64_t", std::numeric_limits<std::int64_t>::min());
  pass &= check_integral_conversion_case<Real>(
      real_name, "uint64_t", std::numeric_limits<std::uint64_t>::max());
  pass &= check_integral_conversion_case<Real>(real_name, "int", -17);
  pass &= check_integral_conversion_case<Real>(
      real_name, "long", static_cast<long>(-123456789L));
  pass &= check_integral_conversion_case<Real>(
      real_name, "long long", static_cast<long long>(-9007199254740993LL));
  pass &= check_integral_conversion_case<Real>(
      real_name, "unsigned int", std::numeric_limits<unsigned int>::max());
  pass &= check_integral_conversion_case<Real>(
      real_name, "unsigned long", std::numeric_limits<unsigned long>::max());
  pass &= check_integral_conversion_case<Real>(
      real_name, "unsigned long long",
      std::numeric_limits<unsigned long long>::max());

  return pass;
}

bool test_dd_real_int64_constructor() {
  cout << endl;
  cout << "Test 10.  (dd_real int64_t / uint64_t constructors)." << endl;

  const std::uint64_t umax = std::numeric_limits<std::uint64_t>::max();
  const std::int64_t imin = std::numeric_limits<std::int64_t>::min();
  const std::int64_t above_double = 9007199254740993LL;

  const dd_real u(umax);
  const dd_real s(imin);
  const dd_real n(above_double);
  dd_real assigned_u;
  dd_real assigned_s;
  assigned_u = umax;
  assigned_s = imin;

  bool pass = true;
  pass &= (u._hi() == std::ldexp(1.0, 64));
  pass &= (u._lo() == -1.0);
  pass &= (assigned_u._hi() == u._hi());
  pass &= (assigned_u._lo() == u._lo());
  pass &= (s._hi() == -std::ldexp(1.0, 63));
  pass &= (s._lo() == 0.0);
  pass &= (assigned_s._hi() == s._hi());
  pass &= (assigned_s._lo() == s._lo());
  pass &= (n._hi() == std::ldexp(1.0, 53));
  pass &= (n._lo() == 1.0);

  bool rounded_path_threw = false;
  try {
    double rounded_only[1];
    qd::uint64_to_double_expansion(umax, rounded_only, 1);
  } catch (const std::range_error &) {
    rounded_path_threw = true;
  }
  pass &= rounded_path_threw;

  if (flag_verbose) {
    cout << "uint64 max = [" << u._hi() << ", " << u._lo() << "]" << endl;
    cout << "int64 min  = [" << s._hi() << ", " << s._lo() << "]" << endl;
    cout << "2^53+1    = [" << n._hi() << ", " << n._lo() << "]" << endl;
  }

  return pass;
}

bool test_qd_real_int64_constructor() {
  cout << endl;
  cout << "Test 10.  (qd_real int64_t / uint64_t constructors)." << endl;

  const std::uint64_t umax = std::numeric_limits<std::uint64_t>::max();
  const std::int64_t imin = std::numeric_limits<std::int64_t>::min();
  const qd_real u(umax);
  const qd_real s(imin);
  qd_real assigned;
  assigned = umax;

  bool pass = true;
  pass &= (u[0] == std::ldexp(1.0, 64));
  pass &= (u[1] == -1.0);
  pass &= (u[2] == 0.0);
  pass &= (u[3] == 0.0);
  pass &= (s[0] == -std::ldexp(1.0, 63));
  pass &= (s[1] == 0.0);
  pass &= (s[2] == 0.0);
  pass &= (s[3] == 0.0);
  pass &= (assigned == u);

  if (flag_verbose) {
    cout << "uint64 max = [" << u[0] << ", " << u[1] << ", "
         << u[2] << ", " << u[3] << "]" << endl;
  }

  return pass;
}

bool test_td_real_int64_constructor() {
  cout << endl;
  cout << "Test 23.  (td_real int64_t / uint64_t constructors)." << endl;

  const std::uint64_t umax = std::numeric_limits<std::uint64_t>::max();
  const std::int64_t imin = std::numeric_limits<std::int64_t>::min();
  const td_real u(umax);
  const td_real s(imin);
  td_real assigned;
  assigned = umax;

  bool pass = true;
  pass &= (u[0] == std::ldexp(1.0, 64));
  pass &= (u[1] == -1.0);
  pass &= (u[2] == 0.0);
  pass &= (s[0] == -std::ldexp(1.0, 63));
  pass &= (s[1] == 0.0);
  pass &= (s[2] == 0.0);
  pass &= (assigned == u);

  if (flag_verbose) {
    cout << "uint64 max = [" << u[0] << ", " << u[1] << ", "
         << u[2] << "]" << endl;
  }

  return pass;
}

#ifdef QD_HAVE_EDD_REAL
bool test_edd_real_int64_constructor() {
  cout << endl;
  cout << "Test 19.  (edd_real int64_t / uint64_t constructors)." << endl;

  const std::uint64_t umax = std::numeric_limits<std::uint64_t>::max();
  const std::int64_t imin = std::numeric_limits<std::int64_t>::min();
  const edd_real u(umax);
  const edd_real s(imin);
  edd_real assigned;
  assigned = umax;

  bool pass = true;
  pass &= (to_qd_real(u) == qd_real(umax));
  pass &= (to_qd_real(s) == qd_real(imin));
  pass &= (to_qd_real(assigned) == qd_real(umax));
  pass &= (u[1] == (edd_word) 0.0);
  pass &= (s[1] == (edd_word) 0.0);

  if (flag_verbose) {
    cout << "uint64 max = " << to_qd_real(u) << endl;
    cout << "int64 min  = " << to_qd_real(s) << endl;
  }

  return pass;
}
#endif

#ifdef QD_HAVE_EDD_REAL

namespace {

inline edd_word test_edd_fabs(edd_word x) {
#ifdef QD_EDD_WORD_IS_FLOAT64X
  return __builtin_fabsf64x(x);
#else
  return std::fabs(x);
#endif
}

inline edd_word test_edd_ldexp(edd_word x, int e) {
#ifdef QD_EDD_WORD_IS_FLOAT64X
  return __builtin_ldexpf64x(x, e);
#else
  return std::ldexp(x, e);
#endif
}

class qd_fpu_scope {
public:
  qd_fpu_scope() : old_cw_(0) { fpu_fix_start(&old_cw_); }
  ~qd_fpu_scope() { fpu_fix_end(&old_cw_); }

private:
  qd_fpu_scope(const qd_fpu_scope &);
  qd_fpu_scope &operator=(const qd_fpu_scope &);

  unsigned int old_cw_;
};

template <class Fn>
qd_real qd_mode_qd(Fn fn) {
  qd_fpu_scope scope;
  return fn();
}

template <class Fn>
dd_real qd_mode_dd(Fn fn) {
  qd_fpu_scope scope;
  return fn();
}

template <class Fn>
bool qd_mode_bool(Fn fn) {
  qd_fpu_scope scope;
  return fn();
}

template <class Fn>
double qd_mode_double(Fn fn) {
  qd_fpu_scope scope;
  return fn();
}

} // namespace

bool edd_nonoverlap(edd_word hi, edd_word lo) {
  if (hi == (edd_word) 0.0) {
    return lo == (edd_word) 0.0;
  }
  return test_edd_fabs(lo) <=
      (edd_word) 0.5 * test_edd_ldexp(test_edd_fabs(hi), -63);
}

bool edd_is_normalized(const edd_real &a) {
  return test_edd_fabs(a[0]) >= test_edd_fabs(a[1]) &&
         edd_nonoverlap(a[0], a[1]);
}

double edd_abs_error(const edd_real &a, const qd_real &ref) {
  return qd_mode_double([&]() {
    return to_double(abs(to_qd_real(a) - ref));
  });
}

double edd_scale(const qd_real &ref) {
  return qd_mode_double([&]() {
    return std::max(1.0, std::abs(to_double(ref)));
  });
}

bool edd_check_close(const edd_real &a, const qd_real &ref, double factor) {
  return edd_abs_error(a, ref) <= factor * static_cast<double>(edd_real::_eps) *
      edd_scale(ref);
}

class EddTestSuite {
public:
  bool test1();
  bool test2();
  bool test3();
  bool test4();
  bool test5();
  bool test6();
  bool test7();
  bool test8();
  bool test9();
  bool test10();
  bool test11();
  bool test12();
  bool test13();
  bool test14();
  bool test15();
  bool test16();
  bool test17();
  bool testall();
};

bool EddTestSuite::test1() {
  cout << endl;
  cout << "Test 1.  (edd normalization invariants after arithmetic)." << endl;

  edd_real a("1.23456789012345678901234567890123456789");
  edd_real b("9.87654321098765432109876543210987654321e-30");
  edd_real c("-8.76543210987654321098765432109876543210e40");

  edd_real sum = a + c;
  edd_real diff = a - b;
  edd_real prod = a * c;
  edd_real quot = c / a;
  edd_real root = sqrt(edd_real("2.0"));

  return edd_is_normalized(sum) && edd_is_normalized(diff) &&
      edd_is_normalized(prod) && edd_is_normalized(quot) &&
      edd_is_normalized(root);
}

bool EddTestSuite::test2() {
  cout << endl;
  cout << "Test 2.  (edd cancellation-sensitive addition / subtraction)." << endl;

  const char *sa = "1.00000000000000011102230246251565404236316680908203125";
  const char *sb = "1.000000000000000055511151231257827021181583404541015625";
  edd_real a(sa);
  edd_real b(sb);
  edd_real diff = a - b;
  edd_real back = diff + b;
  qd_real qdiff = qd_mode_qd([&]() { return qd_real(sa) - qd_real(sb); });
  qd_real qback = qd_mode_qd([&]() { return qdiff + qd_real(sb); });

  return edd_check_close(diff, qdiff, 32.0) &&
      edd_check_close(back, qback, 32.0);
}

bool EddTestSuite::test3() {
  cout << endl;
  cout << "Test 3.  (edd mixed-magnitude multiplication)." << endl;

  const char *sa = "1.23456789012345678901234567890123456789e30";
  const char *sb = "9.87654321098765432109876543210987654321e-20";
  edd_real a(sa);
  edd_real b(sb);
  edd_real prod = a * b;
  qd_real qprod = qd_mode_qd([&]() { return qd_real(sa) * qd_real(sb); });

  return edd_check_close(prod, qprod, 48.0);
}

bool EddTestSuite::test4() {
  cout << endl;
  cout << "Test 4.  (edd basic division sanity checks)." << endl;

  const char *sa = "1.23456789012345678901234567890123456789e40";
  const char *sb = "9.87654321098765432109876543210987654321e10";
  edd_real a(sa);
  edd_real b(sb);
  edd_real q = a / b;
  edd_real thirds = edd_real("1.0") / edd_real("3.0");
  qd_real qq = qd_mode_qd([&]() { return qd_real(sa) / qd_real(sb); });
  qd_real qthirds = qd_mode_qd([]() { return qd_real(1.0) / qd_real(3.0); });
  qd_real qa = qd_mode_qd([&]() { return qd_real(sa); });

  return edd_check_close(q, qq, 64.0) &&
      edd_check_close(thirds, qthirds, 64.0) &&
      edd_check_close(q * b, qa, 128.0);
}

bool EddTestSuite::test5() {
  cout << endl;
  cout << "Test 5.  (edd sqrt on exact squares)." << endl;

  edd_real square("15241578750190521");
  edd_real exact = sqrt(square);
  qd_real qexact = qd_mode_qd([]() { return qd_real("123456789"); });

  return edd_check_close(exact, qexact, 32.0);
}

bool EddTestSuite::test6() {
  cout << endl;
  cout << "Test 6.  (edd sqrt near 1)." << endl;

  edd_real a = edd_real((edd_word) 1.0) +
      edd_real(test_edd_ldexp((edd_word) 1.0, -63));
  edd_real s = sqrt(a);
  edd_real back = sqr(s);
  qd_real qa = qd_mode_qd([&]() { return to_qd_real(a); });

  return edd_is_normalized(s) && edd_check_close(back, qa, 8.0);
}

bool EddTestSuite::test7() {
  cout << endl;
  cout << "Test 7.  (edd parse / format round trips)." << endl;

  const char *src = "-3.1415926535897932384626433832795028842e+40";
  edd_real a(src);
  std::string s = a.to_string(38, 0, std::ios_base::scientific);
  edd_real b(s.c_str());
  qd_real qsrc = qd_mode_qd([&]() { return qd_real(src); });

  return edd_check_close(a, qsrc, 8.0) &&
      edd_check_close(b, qsrc, 8.0);
}

bool EddTestSuite::test8() {
  cout << endl;
  cout << "Test 8.  (edd constructor / scalar conversion checks)." << endl;

  edd_word x = (edd_word) 1.0 +
      test_edd_ldexp((edd_word) 1.0, -63);
  edd_real a(x);
  edd_real b(1.25);
  edd_real c(7);

  bool pass = (to_float64x(a) == x);
  pass &= (to_double(b) == 1.25);
  pass &= (to_int(c) == 7);
  pass &= (a > (edd_word) 1.0);

  return pass;
}

bool EddTestSuite::test9() {
  cout << endl;
  cout << "Test 9.  (edd constants sanity)." << endl;

  bool pass = true;
  pass &= edd_check_close(edd_real::_pi,
      qd_mode_qd([]() { return qd_real::_pi; }), 8.0);
  pass &= edd_check_close(edd_real::_2pi,
      qd_mode_qd([]() { return qd_real::_2pi; }), 8.0);
  pass &= edd_check_close(edd_real::_3pi4,
      qd_mode_qd([]() { return qd_real::_3pi4; }), 8.0);
  pass &= edd_check_close(edd_real::_pi2,
      qd_mode_qd([]() { return qd_real::_pi2; }), 8.0);
  pass &= edd_check_close(edd_real::_pi4,
      qd_mode_qd([]() { return qd_real::_pi4; }), 8.0);
  pass &= edd_check_close(edd_real::_e,
      qd_mode_qd([]() { return qd_real::_e; }), 8.0);
  pass &= edd_check_close(edd_real::_log2,
      qd_mode_qd([]() { return qd_real::_log2; }), 8.0);
  pass &= edd_check_close(edd_real::_log10,
      qd_mode_qd([]() { return qd_real::_log10; }), 8.0);
  pass &= (edd_real::_2pi > edd_real::_pi);
  pass &= (edd_real::_pi > edd_real::_pi2);
  pass &= (edd_real::_eps > (edd_word) 0.0);
  pass &= (edd_real::_min_normalized > (edd_word) 0.0);
  pass &= (edd_real::_ndigits >= 38);

  return pass;
}

bool EddTestSuite::test10() {
  cout << endl;
  cout << "Test 10.  (edd string I/O round trips and specials)." << endl;

  const char *samples[] = {
    "3.14159265358979323846264338327950288420",
    "-2.71828182845904523536028747135266249776e-200",
    "9.87654321098765432109876543210987654321e+200",
    "  -0.0",
    "6.02214076000000000000000000000000000000e+23"
  };

  bool pass = true;
  for (int i = 0; i < 5; i++) {
    edd_real a(samples[i]);
    std::ostringstream os;
    os << std::setprecision(edd_real::_ndigits) << std::scientific << a;
    std::istringstream is(os.str());
    edd_real b;
    is >> b;
    qd_real qa = qd_mode_qd([&]() { return to_qd_real(a); });
    pass &= edd_check_close(b, qa, 16.0);
  }

  const std::string edd_fixed =
      edd_real(-0.5).to_string(0, 8, std::ios_base::fixed, false, false, '_');
  pass &= (edd_fixed.size() == 8);
  pass &= (edd_fixed.substr(edd_fixed.size() - 2) == "-1");

  pass &= edd_real(" \t+INF\n").isinf();
  pass &= edd_real("-inf").isinf();
  pass &= edd_real("nan").isnan();

  return pass;
}

bool EddTestSuite::test11() {
  cout << endl;
  cout << "Test 11.  (edd mixed-mode binary80 arithmetic and comparisons)." << endl;

  edd_word x = (edd_word) 1.0 + test_edd_ldexp((edd_word) 1.0, -63);
  edd_word y = (edd_word) 3.0;
  edd_real a("1.125");

  bool pass = true;
  pass &= ((a + x) == (a + edd_real(x)));
  pass &= ((x + a) == (edd_real(x) + a));
  pass &= ((a - x) == (a - edd_real(x)));
  pass &= ((x - a) == (edd_real(x) - a));
  pass &= ((a * y) == (a * edd_real(y)));
  pass &= ((y * a) == (edd_real(y) * a));
  pass &= ((a / y) == (a / edd_real(y)));
  pass &= ((y / a) == (edd_real(y) / a));
  pass &= (x > edd_real((edd_word) 1.0));
  pass &= (edd_real((edd_word) 1.0) < x);

  return pass;
}

bool EddTestSuite::test12() {
  cout << endl;
  cout << "Test 12.  (edd dd/qd conversion paths)." << endl;

  dd_real dd = qd_mode_dd([]() {
    return dd_real("1.234567890123456789012345678901");
  });
  edd_real from_dd = to_edd_real(dd);
  dd_real dd_roundtrip = qd_mode_dd([&]() { return to_dd_real(from_dd); });

  qd_real qd = qd_mode_qd([]() {
    return qd_real("1.234567890123456789012345678901234567890123456789");
  });
  edd_real from_qd = to_edd_real(qd);
  qd_real qd_roundtrip = qd_mode_qd([&]() { return to_qd_real(from_qd); });

  const bool dd_roundtrip_ok = qd_mode_bool([&]() {
    return dd == dd_roundtrip;
  });
  const bool from_dd_norm_ok = edd_is_normalized(from_dd);
  const bool from_qd_norm_ok = edd_is_normalized(from_qd);
  const qd_real qdd = qd_mode_qd([&]() { return qd_real(dd); });
  const bool from_dd_close_ok = edd_check_close(from_dd, qdd, 8.0);
  const bool from_qd_close_ok = edd_check_close(from_qd, qd, 8.0);
  const bool qd_roundtrip_ok = qd_mode_bool([&]() {
    return to_double(abs(qd_roundtrip - qd)) <=
        16.0 * static_cast<double>(edd_real::_eps) * edd_scale(qd);
  });

  bool pass = dd_roundtrip_ok && from_dd_norm_ok && from_qd_norm_ok &&
      from_dd_close_ok && from_qd_close_ok && qd_roundtrip_ok;

  if (flag_verbose) {
    cout << "dd           = " << dd << endl;
    cout << "dd_roundtrip = " << dd_roundtrip << endl;
    cout << "from_dd      = " << from_dd << endl;
    cout << "from_qd      = " << from_qd << endl;
    cout << "qd error     = "
         << qd_mode_double([&]() {
              return to_double(abs(qd_roundtrip - qd));
            }) / static_cast<double>(edd_real::_eps)
         << " eps" << endl;
    cout << "from_qd err  = "
         << edd_abs_error(from_qd, qd) / static_cast<double>(edd_real::_eps)
         << " eps" << endl;
    cout << "dd_roundtrip_ok = " << dd_roundtrip_ok << endl;
    cout << "from_dd_norm_ok = " << from_dd_norm_ok << endl;
    cout << "from_qd_norm_ok = " << from_qd_norm_ok << endl;
    cout << "from_dd_close_ok = " << from_dd_close_ok << endl;
    cout << "from_qd_close_ok = " << from_qd_close_ok << endl;
    cout << "qd_roundtrip_ok = " << qd_roundtrip_ok << endl;
  }

  return pass;
}

bool EddTestSuite::test13() {
  cout << endl;
  cout << "Test 13.  (edd overflow / underflow boundary behavior)." << endl;

  edd_real large = ldexp(edd_real((edd_word) 1.0), QD_EDD_WORD_MAX_EXP - 200);
  edd_real tiny = ldexp(edd_real((edd_word) 1.0), -16000);
  edd_real q = large / large;
  edd_real p = large * tiny;
  edd_real s = sqrt(sqr(ldexp(edd_real((edd_word) 1.0), 4000)));

  bool pass = (q == (edd_word) 1.0);
  pass &= p.isfinite();
  pass &= (s == ldexp(edd_real((edd_word) 1.0), 4000));

  return pass;
}

bool EddTestSuite::test14() {
  cout << endl;
  cout << "Test 14.  (edd native exp/log across safe and wide ranges)." << endl;

  edd_real x("1.2345678901234567890123456789");
  edd_real ex = exp(x);
  edd_real lx = log(ex);
  qd_real qx = qd_mode_qd([]() {
    return qd_real("1.2345678901234567890123456789");
  });
  qd_real qex = qd_mode_qd([&]() { return exp(qx); });

  edd_real huge = edd_real::_log2 * (edd_word) 12000.0;
  edd_real ehuge = exp(huge);
  edd_real lhuge = log(ehuge);

  bool pass = true;
  pass &= edd_check_close(ex, qex, 128.0);
  pass &= edd_check_close(lx, qx, 128.0);
  pass &= ehuge.isfinite();
  pass &= edd_is_normalized(ehuge);
  pass &= edd_is_normalized(lhuge);
  pass &= (to_double(abs(lhuge - huge) / abs(huge)) <= 2048.0 * static_cast<double>(edd_real::_eps));

  return pass;
}

bool EddTestSuite::test15() {
  cout << endl;
  cout << "Test 15.  (edd trig identities and qd oracle agreement)." << endl;

  const char *samples[] = {
    "0.125",
    "-1.234567890123456789",
    "21.991148575128552669238503682"
  };

  bool pass = true;
  qd_real qone = qd_mode_qd([]() { return qd_real(1.0); });
  qd_real qzero = qd_mode_qd([]() { return qd_real(0.0); });
  for (int i = 0; i < 3; i++) {
    edd_real a(samples[i]);
    qd_real qa = qd_mode_qd([&]() { return qd_real(samples[i]); });
    qd_real qs = qd_mode_qd([&]() { return sin(qa); });
    qd_real qc = qd_mode_qd([&]() { return cos(qa); });
    qd_real qt = qd_mode_qd([&]() { return tan(qa); });
    edd_real s = sin(a);
    edd_real c = cos(a);
    edd_real t = tan(a);

    pass &= edd_check_close(s, qs, 128.0);
    pass &= edd_check_close(c, qc, 128.0);
    pass &= edd_check_close(t, qt, 256.0);
    pass &= edd_check_close(sqr(s) + sqr(c), qone, 256.0);
    pass &= edd_check_close(t - (s / c), qzero, 256.0);
  }

  return pass;
}

bool EddTestSuite::test16() {
  cout << endl;
  cout << "Test 16.  (edd inverse trig consistency)." << endl;

  edd_real x("0.3125");
  edd_real y("0.75");
  qd_real qx = qd_mode_qd([]() { return qd_real("0.3125"); });
  qd_real qy = qd_mode_qd([]() { return qd_real("0.75"); });
  qd_real qasin = qd_mode_qd([&]() { return asin(qx); });
  qd_real qacos = qd_mode_qd([&]() { return acos(qx); });
  qd_real qatan = qd_mode_qd([&]() { return atan(qy); });
  qd_real qatan2 = qd_mode_qd([&]() { return atan2(qy, qx); });
  qd_real qx_ref = qd_mode_qd([]() { return qd_real("0.3125"); });

  bool pass = true;
  pass &= edd_check_close(asin(x), qasin, 128.0);
  pass &= edd_check_close(acos(x), qacos, 128.0);
  pass &= edd_check_close(atan(y), qatan, 128.0);
  pass &= edd_check_close(atan2(y, x), qatan2, 128.0);
  pass &= edd_check_close(sin(asin(x)), qx_ref, 256.0);
  pass &= edd_check_close(cos(acos(x)), qx_ref, 256.0);

  return pass;
}

bool EddTestSuite::test17() {
  cout << endl;
  cout << "Test 17.  (edd large-argument reduction and hyperbolic checks)." << endl;

  edd_real large = edd_real("1.0e40") * edd_real::_pi + edd_real("0.125");
  qd_real qlarge = qd_mode_qd([&]() { return to_qd_real(large); });
  edd_real h("0.875");
  qd_real qh = qd_mode_qd([]() { return qd_real("0.875"); });

  edd_real s = sin(large);
  edd_real c = cos(large);
  edd_real sh = sinh(h);
  edd_real ch = cosh(h);
  edd_real th = tanh(h);
  qd_real qs = qd_mode_qd([&]() { return sin(qlarge); });
  qd_real qc = qd_mode_qd([&]() { return cos(qlarge); });
  qd_real qsh = qd_mode_qd([&]() { return sinh(qh); });
  qd_real qch = qd_mode_qd([&]() { return cosh(qh); });
  qd_real qth = qd_mode_qd([&]() { return tanh(qh); });
  qd_real qone = qd_mode_qd([]() { return qd_real(1.0); });

  bool pass = true;
  pass &= edd_check_close(s, qs, 256.0);
  pass &= edd_check_close(c, qc, 256.0);
  pass &= edd_check_close(sh, qsh, 128.0);
  pass &= edd_check_close(ch, qch, 128.0);
  pass &= edd_check_close(th, qth, 128.0);
  pass &= edd_check_close(sqr(ch) - sqr(sh), qone, 256.0);

  if (flag_verbose) {
    cout << "large sin err = "
         << edd_abs_error(s, qs) / static_cast<double>(edd_real::_eps)
         << " eps" << endl;
    cout << "large cos err = "
         << edd_abs_error(c, qc) / static_cast<double>(edd_real::_eps)
         << " eps" << endl;
    cout << "sinh err = "
         << edd_abs_error(sh, qsh) / static_cast<double>(edd_real::_eps)
         << " eps" << endl;
    cout << "cosh err = "
         << edd_abs_error(ch, qch) / static_cast<double>(edd_real::_eps)
         << " eps" << endl;
    cout << "tanh err = "
         << edd_abs_error(th, qth) / static_cast<double>(edd_real::_eps)
         << " eps" << endl;
    cout << "cosh^2-sinh^2 err = "
         << edd_abs_error(sqr(ch) - sqr(sh), qone) / static_cast<double>(edd_real::_eps)
         << " eps" << endl;
  }

  return pass;
}

bool EddTestSuite::testall() {
  bool pass = true;
  pass &= print_result(test1());
  pass &= print_result(test2());
  pass &= print_result(test3());
  pass &= print_result(test4());
  pass &= print_result(test5());
  pass &= print_result(test6());
  pass &= print_result(test7());
  pass &= print_result(test8());
  pass &= print_result(test9());
  pass &= print_result(test10());
  pass &= print_result(test11());
  pass &= print_result(test12());
  pass &= print_result(test13());
  pass &= print_result(test14());
  pass &= print_result(test15());
  pass &= print_result(test16());
  pass &= print_result(test17());
  return pass;
}

bool test_edd_real_comparison() {
  cout << endl;
  cout << "Test 18.  (edd comparison normalization)." << endl;

  edd_word lo = test_edd_ldexp((edd_word) 1.0, -63);
  edd_real a((edd_word) 1.0 - lo, lo);
  edd_real b((edd_word) 1.0);
  edd_real diff = a - b;

  bool pass = diff.is_zero();
  pass &= (a == b);
  pass &= !(a != b);
  pass &= !(a < b);
  pass &= !(a > b);
  pass &= (a <= b);
  pass &= (a >= b);
  pass &= (a == (edd_word) 1.0);
  pass &= ((edd_word) 1.0 == a);

  return pass;
}

#endif

qd_real td_to_qd(const td_real &a) {
  return qd_real(a[0]) + qd_real(a[1]) + qd_real(a[2]);
}

bool td_nonoverlap(double hi, double lo) {
  if (hi == 0.0) {
    return lo == 0.0;
  }
  return std::abs(lo) <= 0.5 * std::ldexp(std::abs(hi), -52);
}

bool td_is_normalized(const td_real &a) {
  return std::abs(a[0]) >= std::abs(a[1]) &&
         std::abs(a[1]) >= std::abs(a[2]) &&
         td_nonoverlap(a[0], a[1]) &&
         td_nonoverlap(a[1], a[2]);
}

double td_abs_error(const td_real &a, const qd_real &ref) {
  return to_double(abs(td_to_qd(a) - ref));
}

double td_scale(const qd_real &ref) {
  return std::max(1.0, std::abs(to_double(ref)));
}

bool td_check_close(const td_real &a, const qd_real &ref, double factor) {
  return td_abs_error(a, ref) <= factor * td_real::_eps * td_scale(ref);
}

// RAII guard for td_suppress_error_messages.
struct SuppressGuard {
  ~SuppressGuard() { td_suppress_error_messages = false; }
};

class TdTestSuite {
public:
  bool test9();
  bool test10();
  bool test11();
  bool test12();
  bool test13();
  bool test14();
  bool test15();
  bool test16();
  bool test17();
  bool test18();
  bool test19();
  bool test20();
  bool test21();
  bool testall();
};

bool TdTestSuite::test9() {
  cout << endl;
  cout << "Test 9.  (Normalization invariants after arithmetic)." << endl;

  td_real a("1.2345678901234567890123456789012345678901");
  td_real b("9.8765432109876543210987654321098765432109e-40");
  td_real c("-8.7654321098765432109876543210987654321098e20");

  td_real sum = a + c;
  td_real diff = a - b;
  td_real prod = a * c;
  td_real quot = c / a;
  td_real root = sqrt(td_real("2.0"));

  bool pass = td_is_normalized(sum) && td_is_normalized(diff) &&
      td_is_normalized(prod) && td_is_normalized(quot) && td_is_normalized(root);

  if (flag_verbose) {
    cout << "sum  = " << sum << endl;
    cout << "diff = " << diff << endl;
    cout << "prod = " << prod << endl;
    cout << "quot = " << quot << endl;
    cout << "root = " << root << endl;
  }

  return pass;
}

bool TdTestSuite::test10() {
  cout << endl;
  cout << "Test 10.  (Cancellation-sensitive addition / subtraction)." << endl;

  const char *sa = "1.0000000000000002220446049250313080847263336181640625";
  const char *sb = "1.00000000000000011102230246251565404236316680908203125";
  td_real a(sa);
  td_real b(sb);
  td_real diff = a - b;
  td_real back = diff + b;
  qd_real qdiff = qd_real(sa) - qd_real(sb);
  qd_real qback = qdiff + qd_real(sb);

  bool pass = td_check_close(diff, qdiff, 32.0) &&
      td_check_close(back, qback, 32.0);

  if (flag_verbose) {
    cout << "diff = " << diff << endl;
    cout << "back = " << back << endl;
    cout << "diff err = " << td_abs_error(diff, qdiff) / td_real::_eps << " eps" << endl;
    cout << "back err = " << td_abs_error(back, qback) / td_real::_eps << " eps" << endl;
  }

  return pass;
}

bool TdTestSuite::test11() {
  cout << endl;
  cout << "Test 11.  (Multiplication across mixed magnitudes)." << endl;

  const char *sa = "1.2345678901234567890123456789012345678901e150";
  const char *sb = "9.8765432109876543210987654321098765432109e-120";
  td_real a(sa);
  td_real b(sb);
  td_real prod = a * b;
  qd_real qprod = qd_real(sa) * qd_real(sb);

  if (flag_verbose) {
    cout << "prod = " << prod << endl;
    cout << "err  = " << td_abs_error(prod, qprod) / td_real::_eps << " eps" << endl;
  }

  return td_check_close(prod, qprod, 64.0);
}

bool TdTestSuite::test12() {
  cout << endl;
  cout << "Test 12.  (Division sanity checks)." << endl;

  const char *sa = "1.2345678901234567890123456789012345678901e120";
  const char *sb = "9.8765432109876543210987654321098765432109e30";
  td_real a(sa);
  td_real b(sb);
  td_real q = a / b;
  td_real thirds = td_real("1.0") / td_real("3.0");
  qd_real qq = qd_real(sa) / qd_real(sb);
  qd_real qthirds = qd_real(1.0) / qd_real(3.0);

  bool pass = td_check_close(q, qq, 64.0) &&
      td_check_close(thirds, qthirds, 64.0) &&
      td_check_close(q * b, qd_real(sa), 128.0);

  if (flag_verbose) {
    cout << "q      = " << q << endl;
    cout << "thirds = " << thirds << endl;
  }

  return pass;
}

bool TdTestSuite::test13() {
  cout << endl;
  cout << "Test 13.  (sqrt on exact squares and values near 1)." << endl;

  td_real square("15241578750190521");
  td_real exact = sqrt(square);
  td_real near_one("1.0000000000000000000000000000000000000000001");
  td_real near_root = sqrt(near_one);
  qd_real qexact("123456789");
  qd_real qnear = sqrt(qd_real("1.0000000000000000000000000000000000000000001"));

  bool pass = td_check_close(exact, qexact, 32.0) &&
      td_check_close(near_root, qnear, 64.0);

  if (flag_verbose) {
    cout << "exact sqrt = " << exact << endl;
    cout << "near sqrt  = " << near_root << endl;
  }

  return pass;
}

bool TdTestSuite::test14() {
  cout << endl;
  cout << "Test 14.  (Parse / format round trips)." << endl;

  const char *samples[] = {
    "3.1415926535897932384626433832795028841971693993751",
    "-2.7182818284590452353602874713526624977572470937000e-120",
    "9.9999999999999999999999999999999999999999999999999e200",
    "1.2345678901234567890123456789012345678901234567890e-200"
  };

  bool pass = true;
  for (int i = 0; i < 4; i++) {
    td_real a(samples[i]);
    std::ostringstream os;
    os << std::setprecision(td_real::_ndigits) << std::scientific << a;
    std::istringstream is(os.str());
    td_real b;
    is >> b;
    pass &= td_check_close(b, td_to_qd(a), 64.0);

    if (flag_verbose) {
      cout << samples[i] << endl;
      cout << " -> " << os.str() << endl;
    }
  }

  return pass;
}

bool TdTestSuite::test15() {
  cout << endl;
  cout << "Test 15.  (Transcendental identity checks)." << endl;

  td_real x("1.234567890123456789");
  td_real y("0.625");
  td_real a("0.3");
  td_real s;
  td_real c;
  sincos(y, s, c);

  bool pass = true;
  pass &= td_check_close(exp(log(x)), td_to_qd(x), 64.0);
  pass &= td_check_close(log(exp(a)), td_to_qd(a), 64.0);
  pass &= td_check_close(sqr(s) + sqr(c), qd_real(1.0), 96.0);
  pass &= td_check_close(tan(y), td_to_qd(s / c), 96.0);
  pass &= td_check_close(atan(tan(a)), td_to_qd(a), 96.0);
  pass &= td_check_close(asin(sin(a)), td_to_qd(a), 96.0);
  pass &= td_check_close(acos(cos(a)), td_to_qd(a), 96.0);
  pass &= td_check_close(atan2(s, c), td_to_qd(y), 96.0);
  pass &= td_check_close(sqr(cosh(a)) - sqr(sinh(a)), qd_real(1.0), 128.0);

  if (flag_verbose) {
    cout << "exp(log(x)) = " << exp(log(x)) << endl;
    cout << "sin^2+cos^2 = " << (sqr(s) + sqr(c)) << endl;
    cout << "atan2(s,c)  = " << atan2(s, c) << endl;
  }

  return pass;
}

bool TdTestSuite::test16() {
  cout << endl;
  cout << "Test 16.  (Random-value qd oracle comparison)." << endl;

  bool pass = true;
  std::srand(12345);

  for (int i = 0; i < 40; i++) {
    double u = (std::rand() / static_cast<double>(RAND_MAX)) * 2.0 - 1.0;
    double v = (std::rand() / static_cast<double>(RAND_MAX)) * 2.0 - 1.0;
    td_real x = td_real(u) + td_real(v) * td_real("1e-16");
    td_real p = abs(x) + td_real("0.25");

    pass &= td_check_close(sin(x), sin(td_to_qd(x)), 32.0);
    pass &= td_check_close(cos(x), cos(td_to_qd(x)), 32.0);
    pass &= td_check_close(exp(x), exp(td_to_qd(x)), 32.0);
    pass &= td_check_close(log(p), log(td_to_qd(p)), 32.0);
    pass &= td_check_close(tanh(x), tanh(td_to_qd(x)), 32.0);
    pass &= td_check_close(atan(x), atan(td_to_qd(x)), 32.0);
  }

  return pass;
}

bool TdTestSuite::test17() {
  cout << endl;
  cout << "Test 17.  (Boundary-value checks)." << endl;

  td_real root_max = sqrt(td_real::_max);
  td_real log_min = log(td_real(td_real::_min_normalized));
  td_real exp_hi = exp(td_real("800.0"));
  td_real exp_lo = exp(td_real("-800.0"));
  qd_real qroot_max = sqrt(to_qd_real(td_real::_max));
  qd_real qlog_min = log(qd_real(td_real::_min_normalized));

  bool pass = true;
  pass &= root_max.isfinite();
  pass &= td_check_close(root_max, qroot_max, 256.0);
  pass &= td_check_close(log_min, qlog_min, 128.0);
  pass &= exp_hi.isinf();
  pass &= exp_lo.is_zero();

  if (flag_verbose) {
    cout << "sqrt(max) = " << root_max << endl;
    cout << "log(min)  = " << log_min << endl;
  }

  return pass;
}

bool TdTestSuite::test18() {
  cout << endl;
  cout << "Test 18.  (Mixed-mode arithmetic and conversion round trips)." << endl;

  dd_real dd("1.234567890123456789012345678901");
  td_real td("9.876543210987654321098765432109e-10");
  qd_real qd("3.1415926535897932384626433832795028841971");

  td_real mix_add = td + dd;
  td_real mix_mul = dd * td;
  td_real mix_div = td / dd;
  qd_real qd_add = qd + td;
  qd_real qd_sub = td - qd;
  qd_real qd_mul = qd * td;
  qd_real qd_div = qd / (td + td_real("1.0"));
  td_real from_dd = to_td_real(dd);
  td_real from_qd = to_td_real(qd);
  dd_real dd_round = to_dd_real(from_dd);
  qd_real qd_round = to_qd_real(from_qd);
  dd_real dd_self("1.25");
  td_real td_self("1.25");
  qd_real qd_self("1.25");
  td_real td_half("0.5");
  qd_real qd_half("0.5");
  qd_real dd_add_ref = qd_real(dd) + qd_real("0.75");
  qd_real qd_self_ref("0.875");

  bool pass = true;
  pass &= td_check_close(mix_add, qd_real(dd) + td_to_qd(td), 64.0);
  pass &= td_check_close(mix_mul, qd_real(dd) * td_to_qd(td), 64.0);
  pass &= td_check_close(mix_div, td_to_qd(td) / qd_real(dd), 64.0);
  pass &= to_double(abs(qd_add - (qd + td_to_qd(td)))) < 64.0 * td_real::_eps * td_scale(qd_add);
  pass &= to_double(abs(qd_sub - (td_to_qd(td) - qd))) < 64.0 * td_real::_eps * td_scale(qd_sub);
  pass &= to_double(abs(qd_mul - (qd * td_to_qd(td)))) < 64.0 * td_real::_eps * td_scale(qd_mul);
  pass &= to_double(abs(qd_div - (qd / (td_to_qd(td) + qd_real(1.0))))) < 64.0 * td_real::_eps * td_scale(qd_div);
  pass &= abs(to_double(qd_real(dd_round) - qd_real(dd))) < 16.0 * dd_real::_eps;
  pass &= td_check_close(from_qd, qd, 32.0);
  pass &= to_double(abs(qd_round - qd)) < 64.0 * td_real::_eps * td_scale(qd);

  dd_self += td_half;
  dd_self *= td_half;
  td_self += dd;
  td_self -= qd_half;
  qd_self += td_half;
  qd_self *= td_half;

  pass &= abs(to_double(qd_real(dd_self) - qd_real("0.875"))) < 32.0 * dd_real::_eps;
  pass &= td_check_close(td_self, dd_add_ref, 64.0);
  pass &= to_double(abs(qd_self - qd_self_ref)) < 64.0 * td_real::_eps * td_scale(qd_self_ref);
  pass &= (td < qd);
  pass &= (qd > td);

  if (flag_verbose) {
    cout << "mix_add = " << mix_add << endl;
    cout << "mix_mul = " << mix_mul << endl;
    cout << "mix_div = " << mix_div << endl;
  }

  return pass;
}

bool TdTestSuite::test19() {
  cout << endl;
  cout << "Test 19.  (Special values and string robustness)." << endl;

  td_real nan_value("nan");
  td_real inf_value("inf");
  td_real neg_inf("-inf");
  td_real neg_one("-1.0");
  td_suppress_error_messages = true;
  SuppressGuard suppress_guard;
  td_real log_nan = log(neg_one);

  td_real a("12345.678901234567890123456789");
  std::ostringstream sci;
  std::ostringstream fixed;
  sci << std::setprecision(td_real::_ndigits) << std::scientific << std::uppercase << std::showpos << a;
  fixed << std::setprecision(30) << std::fixed << a;

  std::istringstream sci_in(sci.str());
  std::istringstream fixed_in(fixed.str());
  td_real sci_rt;
  td_real fixed_rt;
  sci_in >> sci_rt;
  fixed_in >> fixed_rt;

  bool pass = true;
  pass &= nan_value.isnan();
  pass &= inf_value.isinf();
  pass &= neg_inf.isinf() && neg_inf.is_negative();
  pass &= log_nan.isnan();
  pass &= td_check_close(sci_rt, td_to_qd(a), 64.0);
  pass &= td_check_close(fixed_rt, td_to_qd(a), 128.0);

  if (flag_verbose) {
    cout << "scientific = " << sci.str() << endl;
    cout << "fixed      = " << fixed.str() << endl;
  }

  return pass;
}

bool TdTestSuite::test20() {
  cout << endl;
  cout << "Test 20.  (Deterministic transcendental spot and edge cases)." << endl;

  td_real pos_zero(0.0);
  td_real neg_zero(-0.0);
  td_real near_one("0.999999999999999999999999999999999999999999");
  td_real near_mone("-0.999999999999999999999999999999999999999999");
  td_real near_pi2 = td_real::_pi2 - td_real("1e-20");
  td_real large_angle("123456.125");
  td_real x("0.125");
  td_real y("-0.75");
  td_real s;
  td_real c;
  td_real sh;
  td_real ch;

  struct TdTrigRegressionCase {
    const char *name;
    td_real input;
  };

  const TdTrigRegressionCase trig_regressions[] = {
      {"tan_conditioned_seed2026061401",
       td_real(-0xe.9a8b013bfe008p-7, -0xe.45e0495da8958p-63,
               0xa.bdc27e4a9938p-117)},
      {"tan_conditioned_seed777",
       td_real(0xb.d4db0d11f39dp+1, -0x8.a1d8a76b1aa08p-53,
               0xb.f6a914b7a3f98p-107)},
      {"tan_stable_seed777",
       td_real(0xe.9cc5967edc268p-1, 0xd.0ad64f8c3a9c8p-56,
               -0xa.10646deab5e6p-110)}};

  sincos(near_pi2, s, c);
  sincosh(x, sh, ch);

  bool pass = true;
  pass &= td_check_close(log10(td_real("1000.0")), qd_real(3.0), 64.0);
  pass &= sin(pos_zero).is_zero() && !std::signbit(sin(pos_zero)[0]);
  pass &= sin(neg_zero).is_zero() && std::signbit(sin(neg_zero)[0]);
  pass &= cos(pos_zero).is_one();
  pass &= td_check_close(s, sin(td_to_qd(near_pi2)), 96.0);
  pass &= td_check_close(c, cos(td_to_qd(near_pi2)), 128.0);
  pass &= td_check_close(tan(near_pi2) * c, td_to_qd(s), 128.0);
  pass &= td_check_close(sin(large_angle), sin(td_to_qd(large_angle)), 768.0);
  pass &= td_check_close(cos(large_angle), cos(td_to_qd(large_angle)), 768.0);
  pass &= td_check_close(asin(near_one), asin(td_to_qd(near_one)), 128.0);
  pass &= td_check_close(acos(near_mone), acos(td_to_qd(near_mone)), 128.0);
  pass &= td_check_close(atan2(y, x), atan2(td_to_qd(y), td_to_qd(x)), 96.0);
  pass &= td_check_close(sh, sinh(td_to_qd(x)), 64.0);
  pass &= td_check_close(ch, cosh(td_to_qd(x)), 64.0);
  pass &= td_check_close(tanh(y), tanh(td_to_qd(y)), 64.0);
  pass &= td_check_close(asinh(y), asinh(td_to_qd(y)), 96.0);
  pass &= td_check_close(acosh(td_real("1.5")), acosh(qd_real("1.5")), 128.0);
  pass &= td_check_close(atanh(td_real("0.125")), atanh(qd_real("0.125")), 96.0);

  for (int i = 0; i < static_cast<int>(sizeof(trig_regressions) /
                                       sizeof(trig_regressions[0])); i++) {
    const td_real &angle = trig_regressions[i].input;
    pass &= td_check_close(sin(angle), sin(td_to_qd(angle)), 8.0);
    pass &= td_check_close(cos(angle), cos(td_to_qd(angle)), 8.0);
    pass &= td_check_close(tan(angle), tan(td_to_qd(angle)), 8.0);
  }

  if (flag_verbose) {
    cout << "sin(pi/2 - 1e-20) = " << s << endl;
    cout << "cos(pi/2 - 1e-20) = " << c << endl;
    cout << "sin(large)        = " << sin(large_angle) << endl;
    cout << "atan2(y, x)       = " << atan2(y, x) << endl;
    for (int i = 0; i < static_cast<int>(sizeof(trig_regressions) /
                                         sizeof(trig_regressions[0])); i++) {
      cout << trig_regressions[i].name << " = "
           << trig_regressions[i].input << endl;
    }
  }

  return pass;
}

bool TdTestSuite::test21() {
  cout << endl;
  cout << "Test 21.  (Randomized native transcendental regression checks)." << endl;

  bool pass = true;
  std::srand(24680);

  for (int i = 0; i < 48; i++) {
    double u = (std::rand() / static_cast<double>(RAND_MAX)) * 10.0 - 5.0;
    double v = (std::rand() / static_cast<double>(RAND_MAX)) * 10.0 - 5.0;
    double w = (std::rand() / static_cast<double>(RAND_MAX)) * 0.98 - 0.49;

    td_real x = td_real(u) + td_real(v) * td_real("1e-15");
    td_real positive = abs(x) + td_real("0.125");
    td_real unit = td_real(w) + td_real("1e-16");
    td_real angle = x * td_real::_pi4;
    td_real sx;
    td_real cx;

    sincos(angle, sx, cx);

    pass &= td_check_close(exp(x), exp(td_to_qd(x)), 64.0);
    pass &= td_check_close(log(positive), log(td_to_qd(positive)), 64.0);
    pass &= td_check_close(log10(positive), log10(td_to_qd(positive)), 96.0);
    pass &= td_check_close(sx, sin(td_to_qd(angle)), 96.0);
    pass &= td_check_close(cx, cos(td_to_qd(angle)), 96.0);
    pass &= td_check_close(tan(unit), tan(td_to_qd(unit)), 128.0);
    pass &= td_check_close(atan(x), atan(td_to_qd(x)), 64.0);
    pass &= td_check_close(atan2(x, positive), atan2(td_to_qd(x), td_to_qd(positive)), 96.0);
    pass &= td_check_close(asin(unit), asin(td_to_qd(unit)), 128.0);
    pass &= td_check_close(acos(unit), acos(td_to_qd(unit)), 128.0);
    pass &= td_check_close(sinh(unit), sinh(td_to_qd(unit)), 64.0);
    pass &= td_check_close(cosh(unit), cosh(td_to_qd(unit)), 64.0);
    pass &= td_check_close(tanh(unit), tanh(td_to_qd(unit)), 64.0);
  }

  return pass;
}

bool TdTestSuite::testall() {
  bool pass = true;
  pass &= print_result(test9());
  pass &= print_result(test10());
  pass &= print_result(test11());
  pass &= print_result(test12());
  pass &= print_result(test13());
  pass &= print_result(test14());
  pass &= print_result(test15());
  pass &= print_result(test16());
  pass &= print_result(test17());
  pass &= print_result(test18());
  pass &= print_result(test19());
  pass &= print_result(test20());
  pass &= print_result(test21());
  return pass;
}

}  // namespace

/* Test 1.   Polynomial Evaluation / Polynomial Solving */
template <class T>
bool TestSuite<T>::test1() {
  cout << endl;
  cout << "Test 1.  (Polynomial)." << endl;

  static const int n = 8;
  std::vector<T> c(n);
  T x, y;

  for (int i = 0; i < n; i++)
    c[i] = static_cast<double>(i+1);

  x = polyroot(c.data(), n-1, T(0.0));
  y = polyeval(c.data(), n-1, x);

  if (flag_verbose) {
    cout.precision(T::_ndigits);
    cout << "Root Found:  x  = " << x << endl;
    cout << "           p(x) = " << y << endl;
  }

  return (to_double(y) < 4.0 * T::_eps);
}

/* Test 2.  Machin's Formula for Pi. */
template <class T>
bool TestSuite<T>::test2() {

  cout << endl;
  cout << "Test 2.  (Machin's Formula for Pi)." << endl;

  /* Use the Machin's arctangent formula:

       pi / 4  =  4 arctan(1/5) - arctan(1/239)

     The arctangent is computed based on the Taylor series expansion

       arctan(x) = x - x^3 / 3 + x^5 / 5 - x^7 / 7 + ...
  */

  T s1, s2, t, r;
  int k;
  int sign;
  double d;
  double err;

  /* Compute arctan(1/5) */
  d = 1.0;
  t = T(1.0) / 5.0;
  r = sqr(t);
  s1 = 0.0;
  k = 0;

  sign = 1;
  while (t > T::_eps) {
    k++;
    if (sign < 0)
      s1 -= (t / d);
    else
      s1 += (t / d);

    d += 2.0;
    t *= r;
    sign = -sign;
  }

  if (flag_verbose)
    cout << k << " Iterations" << endl;

  /* Compute arctan(1/239) */
  d = 1.0;
  t = T(1.0) / 239.0;
  r = sqr(t);
  s2 = 0.0;
  k = 0;

  sign = 1;
  while (t > T::_eps) {
    k++;
    if (sign < 0)
      s2 -= (t / d);
    else
      s2 += (t / d);

    d += 2.0;
    t *= r;
    sign = -sign;
  }

  if (flag_verbose)
    cout << k << " Iterations" << endl;

  T p = 4.0 * s1 - s2;

  p *= 4.0;
  err = abs(to_double(p - T::_pi));

  if (flag_verbose) {
    cout.precision(T::_ndigits);
    cout << "   pi = " << p << endl;
    cout << "  _pi = " << T::_pi << endl;

    cout.precision(double_digits);
    cout << "error = " << err << " = " << err / T::_eps << " eps" << endl;
  }

  return (err < 8.0 * T::_eps);
}

/* Test 3.  Salamin-Brent Quadratic Formula for Pi. */
template <class T>
bool TestSuite<T>::test3() {
  cout << endl;
  cout << "Test 3.  (Salamin-Brent Quadratic Formula for Pi)." << endl;
  cout.precision(T::_ndigits);

  T a, b, s, p;
  T a_new, b_new, p_old;
  double m;
  double err;
  const int max_iter = 20;

  a = 1.0;
  b = sqrt(T(0.5));
  s = 0.5;
  m = 1.0;

  p = 2.0 * sqr(a) / s;
  if (flag_verbose)
    cout << "Iteration  0: " << p << endl;
  for (int i = 1; i <= max_iter; i++) {
    m *= 2.0;
    a_new = 0.5 * (a + b);
    b_new = a * b;
    s -= m * (sqr(a_new) - b_new);
    a = a_new;
    b = sqrt(b_new);
    p_old = p;
    p = 2.0 * sqr(a) / s;
    if (flag_verbose)
      cout << "Iteration " << std::setw(2) << i << ": " << p << endl;
    if (abs(to_double(p - p_old)) < 64 * T::_eps)
      break;
  }

  err = abs(to_double(p - T::_pi));

  if (flag_verbose) {
    cout << "         _pi: " << T::_pi << endl;
    cout.precision(double_digits);
    cout << "       error: " << err << " = " << err / T::_eps << " eps" << endl;
  }

  // for some reason, this test gives relatively large error compared
  // to other tests.  May need to be looked at more closely.
  return (err < 1024.0 * T::_eps);
}

/* Test 4.  Borwein Quartic Formula for Pi. */
template <class T>
bool TestSuite<T>::test4() {
  cout << endl;
  cout << "Test 4.  (Borwein Quartic Formula for Pi)." << endl;
  cout.precision(T::_ndigits);

  T a, y, p, r, p_old;
  double m;
  double err;
  const int max_iter = 20;

  a = 6.0 - 4.0 * sqrt(T(2.0));
  y = sqrt(T(2.0)) - 1.0;
  m = 2.0;

  p = 1.0 / a;
  if (flag_verbose)
    cout << "Iteration  0: " << p << endl;

  for (int i = 1; i <= max_iter; i++) {
    m *= 4.0;
    r = nroot(1.0 - sqr(sqr(y)), 4);
    y = (1.0 - r) / (1.0 + r);
    a = a * sqr(sqr(1.0 + y)) - m * y * (1.0 + y + sqr(y));

    p_old = p;
    p = 1.0 / a;
    if (flag_verbose)
      cout << "Iteration " << std::setw(2) << i << ": " << p << endl;
    if (abs(to_double(p - p_old)) < 16 * T::_eps)
      break;
  }

  err = abs(to_double(p - T::_pi));
  if (flag_verbose) {
    cout << "         _pi: " << T::_pi << endl;
    cout.precision(double_digits);
    cout << "       error: " << err << " = " << err / T::_eps << " eps" << endl;
  }

  return (err < 256.0 * T::_eps);
}

/* Test 5.  Taylor Series Formula for E. */
template <class T>
bool TestSuite<T>::test5() {

  cout << endl;
  cout << "Test 5.  (Taylor Series Formula for E)." << endl;
  cout.precision(T::_ndigits);

  /* Use Taylor series

       e = 1 + 1 + 1/2! + 1/3! + 1/4! + ...

     To compute e.
  */

  T s = 2.0, t = 1.0;
  double n = 1.0;
  double delta;
  int i = 0;

  while (t > T::_eps) {
    i++;
    n += 1.0;
    t /= n;
    s += t;
  }

  delta = abs(to_double(s - T::_e));

  if (flag_verbose) {
    cout << "    e = " << s << endl;
    cout << "   _e = " << T::_e << endl;

    cout.precision(double_digits);
    cout << "error = " << delta << " = " << delta / T::_eps << " eps" << endl;
    cout << i << " iterations." << endl;
  }

  return (delta < 64.0 * T::_eps);
}

/* Test 6.  Taylor Series Formula for log 2.*/
template <class T>
bool TestSuite<T>::test6() {
  cout << endl;
  cout << "Test 6.  (Taylor Series Formula for Log 2)." << endl;
  cout.precision(T::_ndigits);

  /* Use the Taylor series

      -log(1-x) = x + x^2/2 + x^3/3 + x^4/4 + ...

     with x = 1/2 to get  log(1/2) = -log 2.
  */

  T s = 0.5;
  T t = 0.5;
  double delta;
  double n = 1.0;
  int i = 0;

  while (abs(t) > T::_eps) {
    i++;
    n += 1.0;
    t *= 0.5;
    s += (t/n);
  }

  delta = abs(to_double(s - T::_log2));

  if (flag_verbose) {
    cout << " log2 = " << s << endl;
    cout << "_log2 = " << T::_log2 << endl;

    cout.precision(double_digits);
    cout << "error = " << delta << " = " << (delta / T::_eps)
         << " eps" << endl;
    cout << i << " iterations." << endl;
  }

  return (delta < 4.0 * T::_eps);
}

/* Test 7.  Sanity check for exp. */
template <class T>
bool TestSuite<T>::test7() {
  cout << endl;
  cout << "Test 7.  (Sanity check for exp)." << endl;
  cout.precision(T::_ndigits);

  /* Do simple sanity check
   *
   *   e^2 = exp(2)
   *       = exp(-13/4) * exp(-9/4) * exp(-5/4) * exp(-1/4) *
   *         exp(3/4) * exp(7/4) * exp(11/4) * exp(15/4)
   */

  T t = -3.25;
  T p =  1.0;

  for (int i = 0; i < 8; i++, t += 1.0) {
    /* For some reason gcc-4.1.x on x86_64 miscompiles p *= exp(t) here. */
    p = p * exp(t);
  }

  T t1 = exp(T(2.0));
  T t2 = sqr(T::_e);
  double delta = std::max(abs(to_double(t1 - p)), abs(to_double(t2 - p)));

  if (flag_verbose) {
    cout << "result = " << p << endl;
    cout << "exp(2) = " << t1 << endl;
    cout << "   e^2 = " << t2 << endl;

    cout.precision(double_digits);

    cout << " error = " << delta << " = " << (delta / T::_eps)
         << " eps" << endl;
  }

  return (delta < 16.0 * T::_eps);
}

template <class T>
bool TestSuite<T>::test8() {
  cout << endl;
  cout << "Test 8.  (Sanity check for sin / cos)." << endl;
  cout.precision(T::_ndigits);

  /* Do simple sanity check
   *
   *  sin(x) = sin(5x/7)cos(2x/7) + cos(5x/7)sin(2x/7)
   *
   *  cos(x) = cos(5x/7)cos(2x/7) - sin(5x/7)sin(2x/7);
   */

  T x = T::_pi / 3.0;
  T x1 = 5.0 * x / 7.0;
  T x2 = 2.0 * x / 7.0;

  T r1 = sin(x1)*cos(x2) + cos(x1)*sin(x2);
  T r2 = cos(x1)*cos(x2) - sin(x1)*sin(x2);
  T t1 = sqrt(T(3.0)) / 2.0;
  T t2 = 0.5;

  double delta = std::max(abs(to_double(t1 - r1)), abs(to_double(t2 - r2)));

  if (flag_verbose) {
    cout << "  r1 = " << r1 << endl;
    cout << "  t1 = " << t1 << endl;
    cout << "  r2 = " << r2 << endl;
    cout << "  t2 = " << t2 << endl;

    cout.precision(double_digits);
    cout << " error = " << delta << " = " << (delta / T::_eps)
         << " eps" << endl;
  }

  return (delta < 4.0 * T::_eps);
}

bool test_qd_real_comparison() {
  cout << endl;
  cout << "Test 9.  (qd_real comparison normalization)." << endl;

  qd_real a(1.0, 0.5, 0.0, 0.0);
  qd_real b(1.5);
  qd_real diff = a - b;
  diff.renorm();

  bool pass = diff.is_zero();
  pass &= (a == b);
  pass &= !(a != b);
  pass &= !(a < b);
  pass &= !(a > b);
  pass &= (a <= b);
  pass &= (a >= b);

  pass &= (a == 1.5);
  pass &= (1.5 == a);
  pass &= (a == dd_real(1.5));
  pass &= (dd_real(1.5) == a);

  if (flag_verbose) {
    cout << "a = [" << a[0] << ", " << a[1] << ", "
         << a[2] << ", " << a[3] << "]" << endl;
    cout << "b = " << b << endl;
    cout << "renormalized diff is zero: " << diff.is_zero() << endl;
  }

  return pass;
}

bool test_dd_real_comparison() {
  cout << endl;
  cout << "Test 9.  (dd_real comparison normalization)." << endl;

  double lo = std::ldexp(1.0, -53);
  dd_real a(1.0 - lo, lo);
  dd_real b(1.0);
  dd_real diff = a - b;

  bool pass = diff.is_zero();
  pass &= (a == b);
  pass &= !(a != b);
  pass &= !(a < b);
  pass &= !(a > b);
  pass &= (a <= b);
  pass &= (a >= b);

  pass &= (a == 1.0);
  pass &= (1.0 == a);

  if (flag_verbose) {
    cout << "a = [" << a._hi() << ", " << a._lo() << "]" << endl;
    cout << "b = " << b << endl;
    cout << "diff is zero: " << diff.is_zero() << endl;
  }

  return pass;
}

bool test_td_real_comparison() {
  cout << endl;
  cout << "Test 22.  (td_real comparison normalization)." << endl;

  double lo = std::ldexp(1.0, -53);
  td_real a(1.0 - lo, lo, 0.0);
  td_real b(1.0);
  td_real diff = a - b;

  bool pass = diff.is_zero();
  pass &= (a == b);
  pass &= !(a != b);
  pass &= !(a < b);
  pass &= !(a > b);
  pass &= (a <= b);
  pass &= (a >= b);

  pass &= (a == 1.0);
  pass &= (1.0 == a);
  pass &= (a == dd_real(1.0));
  pass &= (dd_real(1.0) == a);
  pass &= (a == qd_real(1.0));
  pass &= (qd_real(1.0) == a);

  if (flag_verbose) {
    cout << "a = [" << a[0] << ", " << a[1] << ", " << a[2] << "]" << endl;
    cout << "b = " << b << endl;
    cout << "diff is zero: " << diff.is_zero() << endl;
  }

  return pass;
}


template <class T>
bool TestSuite<T>::test9() {
  cout << endl;
  cout << "Test 9.  (Fixed zero-precision formatting preserves width)." << endl;

  const std::string negative =
      T(-0.5).to_string(0, 8, std::ios_base::fixed, false, false, '_');
  const std::string positive =
      T(0.5).to_string(0, 8, std::ios_base::fixed, false, false, '_');

  bool pass = true;
  pass &= (negative.size() == 8);
  pass &= (positive.size() == 8);
  pass &= (negative.substr(negative.size() - 2) == "-1");
  pass &= (positive.substr(positive.size() - 1) == "1");

  if (flag_verbose) {
    cout << "negative fixed text = '" << negative << "'" << endl;
    cout << "positive fixed text = '" << positive << "'" << endl;
  }

  return pass;
}

template <class T>
bool TestSuite<T>::testall() {
  bool pass = true;
  pass &= print_result(test1());
  pass &= print_result(test2());
  pass &= print_result(test3());
  pass &= print_result(test4());
  pass &= print_result(test5());
  pass &= print_result(test6());
  pass &= print_result(test7());
  pass &= print_result(test8());
  pass &= print_result(test9());
  return pass;
}

void print_usage() {
  cout << "qd_test [-h] [-dd] [-td] [-qd] [-all]" << endl;
  cout << "  Performs miscellaneous tests of the quad-double library," << endl;
  cout << "  such as polynomial root finding, computation of pi, etc." << endl;
  cout << endl;
  cout << "  -h -help  Prints this usage message." << endl;
  cout << "  -dd       Perform tests with double-double types." << endl;
  cout << "  -td       Perform tests with triple-double types." << endl;
  cout << "  -qd       Perform tests with quad-double types." << endl;
#ifdef QD_HAVE_EDD_REAL
  cout << "  -edd      Perform tests with extended-double-double types." << endl;
#endif
  cout << "  -all      Perform double-double, triple-double, and quad-double tests." << endl;
  cout << "  -v" << endl;
  cout << "  -verbose  Print detailed information for each test." << endl;

}

int main(int argc, char *argv[]) {

  bool pass = true;
  unsigned int old_cw;
  fpu_fix_start(&old_cw);

  /* Parse the arguments. */
  char *arg;
  for (int i = 1; i < argc; i++) {
    arg = argv[i];
    if (strcmp(arg, "-h") == 0 || strcmp(arg, "-help") == 0) {
      print_usage();
      exit(0);
    } else if (strcmp(arg, "-dd") == 0) {
      flag_test_dd = true;
    } else if (strcmp(arg, "-td") == 0) {
      flag_test_td = true;
    } else if (strcmp(arg, "-qd") == 0) {
      flag_test_qd = true;
#ifdef QD_HAVE_EDD_REAL
    } else if (strcmp(arg, "-edd") == 0) {
      flag_test_edd = true;
#endif
    } else if (strcmp(arg, "-all") == 0) {
#ifdef QD_HAVE_EDD_REAL
      flag_test_dd = flag_test_td = flag_test_qd = flag_test_edd = true;
#else
      flag_test_dd = flag_test_td = flag_test_qd = true;
#endif
    } else if (strcmp(arg, "-v") == 0 || strcmp(arg, "-verbose") == 0) {
      flag_verbose = true;
    } else {
      cerr << "Unknown flag `" << arg << "'." << endl;
    }
  }

  /* If no flag, test both double-double and quad-double. */
  if (!flag_test_dd && !flag_test_td && !flag_test_qd
#ifdef QD_HAVE_EDD_REAL
      && !flag_test_edd
#endif
      ) {
    flag_test_dd = true;
    flag_test_td = true;
    flag_test_qd = true;
#ifdef QD_HAVE_EDD_REAL
    flag_test_edd = true;
#endif
  }

  if (flag_test_dd) {
    TestSuite<dd_real> dd_test;

    cout << endl;
    cout << "Testing dd_real ..." << endl;
    if (flag_verbose)
      cout << "sizeof(dd_real) = " << sizeof(dd_real) << endl;
    pass &= dd_test.testall();
    pass &= print_result(test_dd_real_comparison());
    pass &= print_result(test_dd_real_int64_constructor());
    pass &= print_result(
        test_integral_template_conversions<dd_real>("dd_real", "Test 10b."));
  }

  if (flag_test_qd) {
    TestSuite<qd_real> qd_test;

    cout << endl;
    cout << "Testing qd_real ..." << endl;
    if (flag_verbose)
      cout << "sizeof(qd_real) = " << sizeof(qd_real) << endl;
    pass &= qd_test.testall();
    pass &= print_result(test_qd_real_comparison());
    pass &= print_result(test_qd_real_int64_constructor());
    pass &= print_result(
        test_integral_template_conversions<qd_real>("qd_real", "Test 10b."));
  }

  if (flag_test_td) {
    TestSuite<td_real> td_base_test;
    TdTestSuite td_test;

    cout << endl;
    cout << "Testing td_real ..." << endl;
    if (flag_verbose)
      cout << "sizeof(td_real) = " << sizeof(td_real) << endl;
    pass &= td_base_test.testall();
    pass &= td_test.testall();
    pass &= print_result(test_td_real_comparison());
    pass &= print_result(test_td_real_int64_constructor());
    pass &= print_result(
        test_integral_template_conversions<td_real>("td_real", "Test 23b."));
  }

#ifdef QD_HAVE_EDD_REAL
  if (flag_test_edd) {
    EddTestSuite edd_test;

    /* edd_real relies on binary80 limbs, while the dd/qd/td tests above
       intentionally use the round-to-double fix. */
    unsigned int old_edd_cw = 0;
    fpu_fix_start_80bit(&old_edd_cw);

    cout << endl;
    cout << "Testing edd_real ..." << endl;
    if (flag_verbose)
      cout << "sizeof(edd_real) = " << sizeof(edd_real) << endl;
    pass &= edd_test.testall();
    pass &= print_result(test_edd_real_comparison());
    pass &= print_result(test_edd_real_int64_constructor());
    pass &= print_result(
        test_integral_template_conversions<edd_real>("edd_real", "Test 19b."));
    fpu_fix_end(&old_edd_cw);
  }
#endif

  fpu_fix_end(&old_cw);
  return (pass ? 0 : 1);
}
